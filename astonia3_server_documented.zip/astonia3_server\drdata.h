/**
 * @file drdata.h
 * @brief Driver Data ID definitions for the Astonia 3 server
 *
 * This header defines unique IDs for all driver data blocks that can be
 * attached to characters. The driver system allows NPCs and players to have
 * custom data associated with them for:
 *
 * - **NPC AI State**: Memory, targets, patrol routes
 * - **Quest Progress**: Player's progress through various quests
 * - **Persistent Data**: Data saved to database between sessions
 * - **Temporary Data**: Runtime state that doesn't persist
 *
 * ## ID Format
 *
 * IDs are constructed using the MAKE_DRD macro:
 * `MAKE_DRD(developer_id, local_number)`
 *
 * This creates a 32-bit ID where:
 * - Bits 31: PERSISTENT_PLAYER_DATA flag (if set, data is saved)
 * - Bits 24-30: Developer ID (who created this data type)
 * - Bits 0-23: Local number (unique within developer's namespace)
 *
 * ## Usage
 *
 * ```c
 * // Get or create quest data for player
 * struct quest_data *qd = set_data(cn, DRD_AREA1_PPD, sizeof(*qd));
 *
 * // Read existing data
 * struct quest_data *qd = get_data(cn, DRD_AREA1_PPD, sizeof(*qd));
 *
 * // Delete data
 * del_data(cn, DRD_AREA1_PPD);
 * ```
 *
 * ## Naming Conventions
 *
 * - `DRD_*DRIVER`: NPC AI/behavior driver data
 * - `DRD_*_PPD`: Persistent Player Data (saved to database)
 * - `DRD_*_NPPD`: Non-Persistent Player Data (lost on logout)
 * - `DRD_*_DATA`: Generic data structure
 *
 * @see set_data(), get_data(), del_data() in drdata.c
 *
 * $Id: drdata.h,v 1.8 2008/03/24 11:23:56 devel Exp $ (c) 2005 D.Brockhaus
 *
 * $Log: drdata.h,v $
 * Revision 1.8  2008/03/24 11:23:56  devel
 * arkhata
 *
 * Revision 1.7  2007/12/10 10:13:00  devel
 * added carlos quest
 *
 * Revision 1.6  2007/05/26 13:21:02  devel
 * added caligar stuff
 *
 * Revision 1.5  2006/09/14 09:55:22  devel
 * added questlog
 *
 * Revision 1.4  2006/06/26 18:14:11  ssim
 * added logic for rat nest quest
 *
 * Revision 1.3  2006/04/26 16:05:44  ssim
 * added teufelheim arena drd
 *
 * Revision 1.2  2005/12/07 13:36:18  ssim
 * added demon gambler
 *
 */

/*===========================================================================
 * DATA BLOCK ID CONSTRUCTION
 *===========================================================================*/

/**
 * @brief Flag indicating data should be persisted to database
 * When ORed into a DRD ID, the data block will be saved with player data
 */
#define PERSISTENT_PLAYER_DATA	(1<<31)

/*---------------------------------------------------------------------------
 * Developer IDs (1-127)
 * Each developer has a unique namespace to avoid ID collisions
 *---------------------------------------------------------------------------*/

/** @brief Developer ID: Daniel Brockhaus (primary developer) */
#define DEV_ID_DB		1

/** @brief Developer ID: Markus Roeder */
#define DEV_ID_MR		2

/**
 * @brief Macro to construct a driver data ID
 * @param dev_id Developer ID (1-127)
 * @param nr Local number within developer's namespace (0-16M)
 * @return 32-bit unique ID for the data block
 *
 * Add PERSISTENT_PLAYER_DATA flag with OR to make data persist:
 * MAKE_DRD(DEV_ID_DB, 22 | PERSISTENT_PLAYER_DATA)
 */
#define MAKE_DRD(dev_id,nr)	(((dev_id)<<24)|(nr))

/*===========================================================================
 * DRIVER DATA IDS - Daniel Brockhaus (DEV_ID_DB)
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Utility/Scanning Drivers
 *---------------------------------------------------------------------------*/

/** @brief Item scanning functionality */
#define DRD_SCANITEM		MAKE_DRD(DEV_ID_DB,3)

/*---------------------------------------------------------------------------
 * NPC Memory System (DRD_CHARMEM*)
 * Allows NPCs to remember multiple characters (for AI targeting, etc.)
 *---------------------------------------------------------------------------*/

/** @brief Character memory slot 0 (alias for CHARMEM0) */
#define DRD_CHARMEM		MAKE_DRD(DEV_ID_DB,4)
#define DRD_CHARMEM0		MAKE_DRD(DEV_ID_DB,4)
#define DRD_CHARMEM1		MAKE_DRD(DEV_ID_DB,5)
#define DRD_CHARMEM2		MAKE_DRD(DEV_ID_DB,6)
#define DRD_CHARMEM3		MAKE_DRD(DEV_ID_DB,7)
#define DRD_CHARMEM4		MAKE_DRD(DEV_ID_DB,8)
#define DRD_CHARMEM5		MAKE_DRD(DEV_ID_DB,9)
#define DRD_CHARMEM6		MAKE_DRD(DEV_ID_DB,10)
#define DRD_CHARMEM7		MAKE_DRD(DEV_ID_DB,11)

/*---------------------------------------------------------------------------
 * Core NPC Behavior Drivers
 *---------------------------------------------------------------------------*/

/** @brief Tutorial NPC driver (guides new players) */
#define DRD_TUTORDRIVER		MAKE_DRD(DEV_ID_DB,12)

/** @brief Merchant/vendor NPC driver (buying/selling) */
#define DRD_MERCHANTDRIVER	MAKE_DRD(DEV_ID_DB,13)

/** @brief Lost connection handler driver */
#define DRD_LOSTCONDRIVER	MAKE_DRD(DEV_ID_DB,14)

/** @brief Combat AI driver data */
#define DRD_FIGHTDRIVER		MAKE_DRD(DEV_ID_DB,15)

/*---------------------------------------------------------------------------
 * Persistent Player Data - Tutorial and Early Game
 *---------------------------------------------------------------------------*/

/** @brief Tutorial progress tracking (PPD = Persistent Player Data) */
#define DRD_TUTOR_PPD		MAKE_DRD(DEV_ID_DB,16|PERSISTENT_PLAYER_DATA)

/** @brief Treasure chest loot tracking */
#define DRD_TREASURE_CHEST_PPD	MAKE_DRD(DEV_ID_DB,17|PERSISTENT_PLAYER_DATA)

/** @brief First-kill bonus tracking per monster class */
#define DRD_FIRSTKILL_PPD	MAKE_DRD(DEV_ID_DB,18|PERSISTENT_PLAYER_DATA)

#define DRD_SIMPLEBADDYDRIVER	MAKE_DRD(DEV_ID_DB,19)
#define DRD_GWENDYLONDRIVER	MAKE_DRD(DEV_ID_DB,20)
#define DRD_YOAKINDRIVER	MAKE_DRD(DEV_ID_DB,21)
#define DRD_AREA1_PPD		MAKE_DRD(DEV_ID_DB,22|PERSISTENT_PLAYER_DATA)
#define DRD_BALLTRAPSKELLY	MAKE_DRD(DEV_ID_DB,23)
#define DRD_TERIONDRIVER	MAKE_DRD(DEV_ID_DB,24)
#define DRD_JAMESDRIVER		MAKE_DRD(DEV_ID_DB,25)
#define DRD_DARKINDRIVER	MAKE_DRD(DEV_ID_DB,26)
#define DRD_STATS_PPD		MAKE_DRD(DEV_ID_DB,27|PERSISTENT_PLAYER_DATA)
#define DRD_GEREWINDRIVER	MAKE_DRD(DEV_ID_DB,28)
#define DRD_NOOKDRIVER		MAKE_DRD(DEV_ID_DB,29)
#define DRD_LYDIADRIVER		MAKE_DRD(DEV_ID_DB,30)
#define DRD_ROBBERDRIVER	MAKE_DRD(DEV_ID_DB,31)
#define DRD_SANOADRIVER		MAKE_DRD(DEV_ID_DB,32)
#define DRD_ASTURINDRIVER	MAKE_DRD(DEV_ID_DB,33)
#define DRD_RESKINDRIVER	MAKE_DRD(DEV_ID_DB,34)
#define DRD_GUIWYNNDRIVER	MAKE_DRD(DEV_ID_DB,35)
#define DRD_BANKDRIVER		MAKE_DRD(DEV_ID_DB,36)
#define DRD_LOGAINDRIVER	MAKE_DRD(DEV_ID_DB,37)
#define DRD_BANK_PPD		MAKE_DRD(DEV_ID_DB,38|PERSISTENT_PLAYER_DATA)
#define DRD_SEYMOURDRIVER	MAKE_DRD(DEV_ID_DB,39)
#define DRD_AREA3_PPD		MAKE_DRD(DEV_ID_DB,40|PERSISTENT_PLAYER_DATA)
#define DRD_RANK_PPD		MAKE_DRD(DEV_ID_DB,41|PERSISTENT_PLAYER_DATA)
#define DRD_LAMPGHOSTDRIVER	MAKE_DRD(DEV_ID_DB,42)
#define DRD_SUPERIORDRIVER	MAKE_DRD(DEV_ID_DB,43)
#define DRD_TRANSPORT_PPD	MAKE_DRD(DEV_ID_DB,44|PERSISTENT_PLAYER_DATA)
#define DRD_CLANMASTERDRIVER	MAKE_DRD(DEV_ID_DB,45)
#define DRD_CLANFOUND		MAKE_DRD(DEV_ID_DB,46)
#define DRD_PK_PPD		MAKE_DRD(DEV_ID_DB,47|PERSISTENT_PLAYER_DATA)
#define DRD_CLANCLERKDRIVER	MAKE_DRD(DEV_ID_DB,48)
#define DRD_CLANGUARDDRIVER	MAKE_DRD(DEV_ID_DB,49)
#define DRD_KELLYDRIVER		MAKE_DRD(DEV_ID_DB,50)
#define DRD_SECTION_DATA	MAKE_DRD(DEV_ID_DB,51)
#define DRD_MOONIE_DATA		MAKE_DRD(DEV_ID_DB,52)
#define DRD_ASTRO1DRIVER	MAKE_DRD(DEV_ID_DB,53)
#define DRD_ASTRO2DRIVER	MAKE_DRD(DEV_ID_DB,54)
#define DRD_VAMPIREDRIVER	MAKE_DRD(DEV_ID_DB,55)
#define DRD_THOMASDRIVER	MAKE_DRD(DEV_ID_DB,56)
#define DRD_SIRJONESDRIVER	MAKE_DRD(DEV_ID_DB,57)
#define DRD_MACRODRIVER		MAKE_DRD(DEV_ID_DB,58)
#define DRD_VAMPIRE2DRIVER	MAKE_DRD(DEV_ID_DB,59)
#define DRD_MACRO_PPD		MAKE_DRD(DEV_ID_DB,60|PERSISTENT_PLAYER_DATA)
#define DRD_PENT_NPPD		MAKE_DRD(DEV_ID_DB,61)
#define DRD_FLOWER_PPD		MAKE_DRD(DEV_ID_DB,62|PERSISTENT_PLAYER_DATA)
#define DRD_RANDCHEST_PPD	MAKE_DRD(DEV_ID_DB,63|PERSISTENT_PLAYER_DATA)
#define DRD_GATE_WELCOME	MAKE_DRD(DEV_ID_DB,64)
#define DRD_GATE_PPD		MAKE_DRD(DEV_ID_DB,65|PERSISTENT_PLAYER_DATA)
#define DRD_GATE_FIGHT		MAKE_DRD(DEV_ID_DB,66)
#define DRD_DEPOT_PPD		MAKE_DRD(DEV_ID_DB,67|PERSISTENT_PLAYER_DATA)
#define DRD_DEMONSHRINE_PPD	MAKE_DRD(DEV_ID_DB,68|PERSISTENT_PLAYER_DATA)
#define DRD_CLANROBBERDRIVER	MAKE_DRD(DEV_ID_DB,69)
#define DRD_MILITARYMASTER	MAKE_DRD(DEV_ID_DB,70)
#define DRD_MILITARYADVISOR	MAKE_DRD(DEV_ID_DB,71)
#define DRD_MILITARY_PPD	MAKE_DRD(DEV_ID_DB,72|PERSISTENT_PLAYER_DATA)
#define DRD_CLANROBBER_NPPD	MAKE_DRD(DEV_ID_DB,73)
#define DRD_PLRATTACK		MAKE_DRD(DEV_ID_DB,74)
#define DRD_FDEMONDATA		MAKE_DRD(DEV_ID_DB,75)
#define DRD_FARMYDATA		MAKE_DRD(DEV_ID_DB,76)
#define DRD_FARMY_PPD		MAKE_DRD(DEV_ID_DB,77|PERSISTENT_PLAYER_DATA)
#define DRD_TUTORIAL_PPD	MAKE_DRD(DEV_ID_DB,78|PERSISTENT_PLAYER_DATA)
#define DRD_PALACEGUARD		MAKE_DRD(DEV_ID_DB,79)
#define DRD_ALIAS_PPD		MAKE_DRD(DEV_ID_DB,80|PERSISTENT_PLAYER_DATA)
#define DRD_ARENAMASTER		MAKE_DRD(DEV_ID_DB,81)
#define DRD_ARENAFIGHTER	MAKE_DRD(DEV_ID_DB,82)
#define DRD_ARENA_PPD		MAKE_DRD(DEV_ID_DB,83|PERSISTENT_PLAYER_DATA)
#define DRD_ARENAMANAGER	MAKE_DRD(DEV_ID_DB,84)
#define DRD_DUNGEONMASTER	MAKE_DRD(DEV_ID_DB,85)
#define DRD_RANDOMSHRINE_PPD	MAKE_DRD(DEV_ID_DB,86|PERSISTENT_PLAYER_DATA)
#define DRD_RANDOMMASTER	MAKE_DRD(DEV_ID_DB,87)
#define DRD_PROFDRIVER		MAKE_DRD(DEV_ID_DB,88)
#define DRD_CLARADRIVER		MAKE_DRD(DEV_ID_DB,89)
#define DRD_ISLENA		MAKE_DRD(DEV_ID_DB,90)
#define DRD_LOSTCON_PPD		MAKE_DRD(DEV_ID_DB,91|PERSISTENT_PLAYER_DATA)
#define DRD_ISLENA_PPD		MAKE_DRD(DEV_ID_DB,92|PERSISTENT_PLAYER_DATA)
#define DRD_IMPDRIVER		MAKE_DRD(DEV_ID_DB,93)
#define DRD_WILLIAMDRIVER	MAKE_DRD(DEV_ID_DB,94)
#define DRD_HERMITDRIVER	MAKE_DRD(DEV_ID_DB,95)
#define DRD_TWOGUARDDRIVER	MAKE_DRD(DEV_ID_DB,96)
#define DRD_TWOCITY_PPD		MAKE_DRD(DEV_ID_DB,97|PERSISTENT_PLAYER_DATA)
#define DRD_BARKEEPERDRIVER	MAKE_DRD(DEV_ID_DB,98)
#define DRD_SERVANTDRIVER	MAKE_DRD(DEV_ID_DB,99)
#define DRD_IGNORE_PPD		MAKE_DRD(DEV_ID_DB,100|PERSISTENT_PLAYER_DATA)
#define DRD_TELL_DATA		MAKE_DRD(DEV_ID_DB,101)
#define DRD_THIEFGUARDDRIVER	MAKE_DRD(DEV_ID_DB,102)
#define DRD_THIEFMASTERDRIVER	MAKE_DRD(DEV_ID_DB,103)
#define DRD_SANWYNDRIVER	MAKE_DRD(DEV_ID_DB,104)
#define DRD_ORBSPAWN_PPD	MAKE_DRD(DEV_ID_DB,105|PERSISTENT_PLAYER_DATA)
#define DRD_SKELLYDRIVER	MAKE_DRD(DEV_ID_DB,106)
#define DRD_ALCHEMISTDRIVER	MAKE_DRD(DEV_ID_DB,107)
#define DRD_RUNE_PPD		MAKE_DRD(DEV_ID_DB,108|PERSISTENT_PLAYER_DATA)
#define DRD_SWEAR_PPD		MAKE_DRD(DEV_ID_DB,109|PERSISTENT_PLAYER_DATA)
#define DRD_TRADERDRIVER	MAKE_DRD(DEV_ID_DB,110)
#define DRD_NOMADDRIVER		MAKE_DRD(DEV_ID_DB,111)
#define DRD_NOMAD_PPD		MAKE_DRD(DEV_ID_DB,112|PERSISTENT_PLAYER_DATA)
#define DRD_MISC_PPD		MAKE_DRD(DEV_ID_DB,113|PERSISTENT_PLAYER_DATA)
#define DRD_JUNK_PPD		MAKE_DRD(DEV_ID_DB,114|PERSISTENT_PLAYER_DATA)
#define DRD_LABGNOMEDRIVER	MAKE_DRD(DEV_ID_DB,115)
#define DRD_LAB_PPD		MAKE_DRD(DEV_ID_DB,116|PERSISTENT_PLAYER_DATA)
#define DRD_LQ_NPC_DATA		MAKE_DRD(DEV_ID_DB,117)
#define DRD_TESTERDRIVER	MAKE_DRD(DEV_ID_DB,118)
#define DRD_LQ_PLR_DATA		MAKE_DRD(DEV_ID_DB,119)
#define DRD_STRATEGYDRIVER	MAKE_DRD(DEV_ID_DB,120)
#define DRD_STRATEGY_PPD	MAKE_DRD(DEV_ID_DB,121|PERSISTENT_PLAYER_DATA)
#define DRD_RATCHEST_PPD	MAKE_DRD(DEV_ID_DB,122|PERSISTENT_PLAYER_DATA)
#define DRD_RUBYDRIVER		MAKE_DRD(DEV_ID_DB,123)
#define DRD_SIDESTORY_PPD	MAKE_DRD(DEV_ID_DB,124|PERSISTENT_PLAYER_DATA)
#define DRD_DUNGEONFIGHTER	MAKE_DRD(DEV_ID_DB,125)
#define DRD_WARPFIGHTER		MAKE_DRD(DEV_ID_DB,126)
#define DRD_WARP_PPD		MAKE_DRD(DEV_ID_DB,127|PERSISTENT_PLAYER_DATA)
#define DRD_JANITORDRIVER	MAKE_DRD(DEV_ID_DB,128)
#define DRD_SMUGGLECOMDRIVER	MAKE_DRD(DEV_ID_DB,129)
#define DRD_STAFFER_PPD		MAKE_DRD(DEV_ID_DB,130|PERSISTENT_PLAYER_DATA)
#define DRD_CARLOSDRIVER	MAKE_DRD(DEV_ID_DB,131)
#define DRD_COUNTBRANDRIVER	MAKE_DRD(DEV_ID_DB,132)
#define DRD_COUNTESSABRANDRIVER	MAKE_DRD(DEV_ID_DB,133)
#define DRD_DAUGHTERBRANDRIVER	MAKE_DRD(DEV_ID_DB,134)
#define DRD_SPIRITBRANDRIVER	MAKE_DRD(DEV_ID_DB,135)
#define DRD_GUARDBRANDRIVER	MAKE_DRD(DEV_ID_DB,136)
#define DRD_BRENNETHBRANDRIVER	MAKE_DRD(DEV_ID_DB,137)
#define DRD_FORESTBRANDRIVER	MAKE_DRD(DEV_ID_DB,138)
#define DRD_SUPERMAXDRIVER	MAKE_DRD(DEV_ID_DB,139)
#define DRD_BROKLINDRIVER	MAKE_DRD(DEV_ID_DB,140)
#define DRD_ARISTOCRATDRIVER	MAKE_DRD(DEV_ID_DB,141)
#define DRD_YOATINDRIVER	MAKE_DRD(DEV_ID_DB,142)
#define DRD_CHESSYDRIVER	MAKE_DRD(DEV_ID_DB,143)
#define DRD_GRINNICHDRIVER	MAKE_DRD(DEV_ID_DB,144)
#define DRD_SHANRADRIVER	MAKE_DRD(DEV_ID_DB,145)
#define DRD_DWARFCHIEFDRIVER	MAKE_DRD(DEV_ID_DB,146)
#define DRD_LOSTDWARFDRIVER	MAKE_DRD(DEV_ID_DB,147)
#define DRD_DWARFSHAMANDRIVER	MAKE_DRD(DEV_ID_DB,148)
#define DRD_DWARFSMITHDRIVER	MAKE_DRD(DEV_ID_DB,149)
#define DRD_MISSIONGIVEDRIVER	MAKE_DRD(DEV_ID_DB,150)
#define DRD_MISSION_PPD		MAKE_DRD(DEV_ID_DB,151|PERSISTENT_PLAYER_DATA)
#define DRD_CLUBMASTERDRIVER	MAKE_DRD(DEV_ID_DB,152)
#define DRD_CLUBFOUND		MAKE_DRD(DEV_ID_DB,153)
#define DRD_TUNNEL_PPD		MAKE_DRD(DEV_ID_DB,154|PERSISTENT_PLAYER_DATA)
#define DRD_TEUFELGAMBLE	MAKE_DRD(DEV_ID_DB,155)
#define DRD_TEUFELPK		MAKE_DRD(DEV_ID_DB,156)
#define DRD_TEUFELRAT_PPD	MAKE_DRD(DEV_ID_DB,157|PERSISTENT_PLAYER_DATA)
#define DRD_QUESTLOG_PPD	MAKE_DRD(DEV_ID_DB,158|PERSISTENT_PLAYER_DATA)
#define DRD_CALIGAR_PPD		MAKE_DRD(DEV_ID_DB,159|PERSISTENT_PLAYER_DATA)
#define DRD_ROUVENDRIVER	MAKE_DRD(DEV_ID_DB,160)
#define DRD_STDNPCDRIVER	MAKE_DRD(DEV_ID_DB,161)
#define DRD_ARKHATA_PPD		MAKE_DRD(DEV_ID_DB,162|PERSISTENT_PLAYER_DATA)

#define DRD_LAB2_UNDEAD		MAKE_DRD(DEV_ID_MR,1)
#define DRD_LAB2_DEAMON		MAKE_DRD(DEV_ID_MR,2)
#define DRD_LAB2_PLAYER		MAKE_DRD(DEV_ID_MR,3)
#define DRD_LAB2_HERALD		MAKE_DRD(DEV_ID_MR,4)
#define DRD_LAB3_PRISONER	MAKE_DRD(DEV_ID_MR,5)
#define DRD_LAB3_PASSGUARD	MAKE_DRD(DEV_ID_MR,6)
#define DRD_LAB4_GNALB	        MAKE_DRD(DEV_ID_MR,7)
#define DRD_LAB4_PLAYER	        MAKE_DRD(DEV_ID_MR,8)
#define DRD_LAB5_CHESTBOX	MAKE_DRD(DEV_ID_MR,9)
#define DRD_LAB5_PLAYER	        MAKE_DRD(DEV_ID_MR,10)
#define DRD_LAB5_DAEMON	        MAKE_DRD(DEV_ID_MR,11)
#define DRD_SALTMINE_WORKER	MAKE_DRD(DEV_ID_MR,12)
#define DRD_SALTMINE_PPD	MAKE_DRD(DEV_ID_MR,13|PERSISTENT_PLAYER_DATA)

/*===========================================================================
 * DRIVER DATA API FUNCTIONS
 *
 * These functions manage the driver data blocks attached to characters.
 * Data blocks provide persistent or temporary storage for NPC AI state,
 * quest progress, and other character-specific information.
 *===========================================================================*/

/**
 * @brief Create or get a data block for a character
 *
 * If the data block already exists, returns pointer to existing data.
 * If it doesn't exist, allocates new block of specified size (zeroed).
 *
 * @param cn Character index to attach data to
 * @param ID Data block ID (DRD_* constant)
 * @param size Size of data structure in bytes
 * @return Pointer to data block, or NULL on allocation failure
 *
 * @example
 * struct quest_data *qd = set_data(cn, DRD_AREA1_PPD, sizeof(*qd));
 * qd->stage = 1;
 */
void *set_data(int cn, int ID, int size);

/**
 * @brief Remove a data block from a character
 *
 * @param cn Character index
 * @param ID Data block ID (DRD_* constant)
 * @return 1 on success, 0 if block not found
 */
int del_data(int cn, int ID);

/**
 * @brief Get existing data block from a character
 *
 * Unlike set_data(), this does NOT create the block if it doesn't exist.
 *
 * @param cn Character index
 * @param ID Data block ID (DRD_* constant)
 * @param size Expected size (for validation, pass sizeof(your_struct))
 * @return Pointer to data block, or NULL if not found or size mismatch
 *
 * @example
 * struct quest_data *qd = get_data(cn, DRD_AREA1_PPD, sizeof(*qd));
 * if (qd && qd->stage >= 3) { ... }
 */
void *get_data(int cn, int ID, int size);

/**
 * @brief Delete ALL data blocks attached to a character
 *
 * Called when a character is destroyed/freed. Frees all memory
 * associated with the character's data blocks.
 *
 * @param cn Character index
 */
void del_all_data(int cn);









