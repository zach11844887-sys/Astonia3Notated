/**
 * @file database.h
 * @brief Database interface for persistent data storage
 *
 * This header provides the interface to the MySQL database backend.
 * The database stores:
 * - Player characters and their data
 * - Area server registration (for multi-server architecture)
 * - Mail system messages
 * - Clan data and logs
 * - Club (guild) data
 * - PvP logs and karma tracking
 *
 * ## Multi-Server Architecture
 *
 * Multiple area servers share a single database. When a player changes areas:
 * 1. Current server saves character to database (save_char)
 * 2. Current server releases lock (release_char)
 * 3. Player reconnects to new area server
 * 4. New server loads character from database (find_login)
 *
 * ## Async Operations
 *
 * Many database operations are asynchronous to prevent blocking:
 * - Start operation with function call
 * - Check completion with check_* function
 * - tick_login() processes pending async results
 *
 * $Id: database.h,v 1.4 2006/12/14 14:29:46 devel Exp $
 */

/*===========================================================================
 * DATABASE LIFECYCLE
 *===========================================================================*/

/** @brief Initialize database connection */
int init_database(void);

/** @brief Clean shutdown of database connection */
void exit_database(void);

/** @brief Periodic cleanup of database state */
void sweep_database(void);

/*===========================================================================
 * CHARACTER PERSISTENCE
 *===========================================================================*/

/**
 * @brief Save character data to database
 * @param cn Character index
 * @param area Target area ID
 * @return 1 on success, 0 on failure
 */
int save_char(int cn, int area);

/**
 * @brief Release database lock on character
 * Called after save when character leaves this server
 */
int release_char(int cn);

/**
 * @brief Attempt to rescue a stuck character
 * Used when character data is corrupted or locked
 * @param ID Character's database ID
 */
int rescue_char(int ID);

/*===========================================================================
 * LOGIN AND AREA MANAGEMENT
 *===========================================================================*/

/**
 * @brief Find and load a character for login
 *
 * Searches database for character matching name/password.
 * If found and available, loads character data.
 *
 * @param name Character name
 * @param password Character password
 * @param area_ptr Output: area where character is located
 * @param cn_ptr Output: character index if on this server
 * @param mirror_ptr Output: mirror number
 * @param ID_ptr Output: database ID
 * @param vendor Client vendor ID
 * @param punique Output: unique session ID
 * @param ip Client IP address (for logging)
 * @return Login result code
 */
int find_login(char *name, char *password, int *area_ptr, int *cn_ptr,
               int *mirror_ptr, int *ID_ptr, int vendor, int *punique, unsigned int ip);

/** @brief Process pending login results (async) */
void tick_login(void);

/** @brief Check if character ID exists in database */
int query_ID(unsigned int ID);

/** @brief Check if character name exists in database */
int query_name(char *name);

/**
 * @brief Transfer character to different area
 * @param cn Character index
 * @param area Target area ID
 * @param x Target X coordinate
 * @param y Target Y coordinate
 */
int change_area(int cn, int area, int x, int y);

/** @brief Check if area ID is valid for character */
int check_area(int ID, int mirror);

/*===========================================================================
 * AREA SERVER COORDINATION
 *===========================================================================*/

/**
 * @brief Get server address for an area
 * @param ID Area ID
 * @param mirror Mirror number
 * @param pserver Output: server IP address
 * @param pport Output: server port
 */
int get_area(int ID, int mirror, int *pserver, int *pport);

/** @brief Get mirror number for area */
int get_mirror(int ID, int mirror);

/**
 * @brief Report this area server as alive/dead
 * @param godown 1 = going offline, 0 = still running
 */
void area_alive(int godown);

/** @brief Trigger area load check */
void call_area_load(void);

/*===========================================================================
 * LOGGING
 *===========================================================================*/

/**
 * @brief Log character/item action to database
 * @param cn Character index (or 0)
 * @param in Item index (or 0)
 * @param format Printf-style format string
 */
int dlog(int cn, int in, char *format, ...) __attribute__ ((format(printf,3,4)));

/** @brief List pending database queries (debug) */
void list_queries(int cn);

/*===========================================================================
 * MAIL SYSTEM
 *===========================================================================*/

/**
 * @brief Retrieve mail messages
 * @param to Recipient character ID
 * @param from Sender character ID (0 for all)
 * @param buf Output buffer
 * @param start Start from this message ID
 * @return Next message ID or 0 if done
 */
unsigned long long get_mail(int to, int from, char *buf, unsigned long long start);

/**
 * @brief Send mail message
 * @param to Recipient character ID
 * @param from Sender character ID
 * @param text Message text
 */
int send_mail(int to, int from, char *text);

/*===========================================================================
 * STORAGE SYSTEM (Persistent Key-Value Store)
 *===========================================================================*/

/** @brief Create new storage entry */
int create_storage(int ID, char *desc, void *content, int size);
int check_create_storage(void);

/** @brief Update existing storage entry */
int update_storage(int ID, int version, void *content, int size);
int check_update_storage(void);

/** @brief Read storage entry */
int read_storage(int ID, int version);
int check_read_storage(int *pversion, void **pptr, int *psize);

/*===========================================================================
 * TASK SYSTEM
 *===========================================================================*/

/** @brief Add task to processing queue */
int add_task(void *task, int len);
void call_check_task(void);

/*===========================================================================
 * NOTES SYSTEM (Character Notes/History)
 *===========================================================================*/

/** @brief Add note to character */
int add_note(int uID, int kind, int cID, unsigned char *content, int clen);

/** @brief Read notes for character */
int read_notes(int uID, int rID);

/** @brief Get last login time for character */
int lastseen(int uID, int rID);

/*===========================================================================
 * SERVER LOCKING
 *===========================================================================*/

/** @brief Acquire server-wide lock (for critical operations) */
void lock_server(void);

/** @brief Release server-wide lock */
void unlock_server(void);

/*===========================================================================
 * ADMIN FUNCTIONS
 *===========================================================================*/

/** @brief Unpunish a character */
int db_unpunish(int ID, void *pm, int pmlen);

/** @brief Delete a character (admin) */
int exterminate(int masterID, char *name, char *staffcode);

/** @brief Rename a character */
int do_rename(int masterID, char *from, char *to);

/** @brief Lock a character name from being used */
int do_lockname(int masterID, char *from);

/** @brief Unlock a previously locked name */
int do_unlockname(int masterID, char *from);

/*===========================================================================
 * CLAN SYSTEM
 *===========================================================================*/

/**
 * @brief Add entry to clan log
 * @param clan Clan ID
 * @param serial Event serial
 * @param cID Character ID
 * @param prio Priority level
 * @param format Message format
 */
int add_clanlog(int clan, int serial, int cID, int prio, char *format, ...) __attribute__ ((format(printf,5,6)));

/** @brief Look up clan log entries */
int lookup_clanlog(int cnID, int clan, int serial, int coID, int prio, int from_time, int to_time);

/*===========================================================================
 * CLUB SYSTEM
 *===========================================================================*/

/** @brief Create new club in database */
int db_create_club(int cnr);

/** @brief Schedule club updates */
void schedule_clubs(void);

/** @brief Update club data in database */
void db_update_club(int cnr);

/*===========================================================================
 * PVP TRACKING
 *===========================================================================*/

/** @brief Start new PvP session logging */
void db_new_pvp(void);

/** @brief Log PvP event */
void db_add_pvp(char *killer, char *victim, char *what, int damage);

/** @brief Get karma log for character */
int karmalog(int rID);

/** @brief Update statistics in database */
void call_stat_update(void);








