/**
 * @file server.h
 * @brief Core server definitions and data structures for Astonia 3 MMORPG Server
 *
 * This header file contains the fundamental definitions, constants, and data structures
 * that form the backbone of the Astonia 3 game server. It defines:
 * - Server version and timing constants
 * - Map tile structure and flags
 * - Item structure and flags (equipment, weapons, containers)
 * - Character structure and flags (players, NPCs, monsters)
 * - Effect structure for spells and visual effects
 * - Character attributes and skills (V_* constants)
 * - Profession system (P_* constants)
 * - Equipment slots (WN_* constants)
 *
 * The server operates on a tick-based system with 24 ticks per second.
 * All game logic, movement, combat, and effects are synchronized to this tick rate.
 *
 * @version 3.01.00
 * @date 2005-2008
 *
 * $Id: server.h,v 1.4 2006/12/14 13:58:05 devel Exp $
 *
 * $Log: server.h,v $
 * Revision 1.4  2006/12/14 13:58:05  devel
 * added xmass special
 *
 * Revision 1.3  2006/08/19 17:27:52  devel
 * increased version to 3.01.00
 *
 * Revision 1.2  2005/11/27 20:03:55  ssim
 * moved CF_WON to a new bit to force all players to do it again
 *
 * Revision 1.1  2005/09/24 09:55:48  ssim
 * Initial revision
 */

/**
 * @brief Server version number encoded as 0xMMmmpp (Major.minor.patch)
 * Current version: 3.01.00
 */
#define VERSION	 0x030100

/*===========================================================================
 * TIMING CONSTANTS
 * The server uses a tick-based timing system for all game updates
 *===========================================================================*/

/** @brief Number of game ticks per second (server update frequency) */
#define TICKS		24

/** @brief Duration of one tick in microseconds (1,000,000 / 24 ≈ 41,667 μs) */
#define TICK		(1000000ull/TICKS)

/*---------------------------------------------------------------------------
 * Decay and Respawn Timers (in ticks)
 * These control how long objects persist in the game world
 *---------------------------------------------------------------------------*/

/** @brief Time before dropped items disappear (5 minutes) */
#define ITEM_DECAY_TIME			(5*60*TICKS)

/** @brief Time before a player's corpse disappears (30 minutes) */
#define	PLAYER_BODY_DECAY_TIME		(30*60*TICKS)

/** @brief Time before an NPC corpse disappears (2 minutes) */
#define NPC_BODY_DECAY_TIME		(2*60*TICKS)

/** @brief Extended NPC corpse decay time for area 32 (15 minutes) */
#define NPC_BODY_DECAY_TIME_AREA32	(15*60*TICKS)

/** @brief Default NPC respawn time (1 minute), can be overridden per-NPC */
#define RESPAWN_TIME			(1*60*TICKS)

/** @brief Time before disconnected player is removed from server (5 minutes) */
#define LAGOUT_TIME			(5*60*TICKS)

/** @brief Idle time before HP/Mana/Endurance regeneration begins (4 ticks) */
#define REGEN_TIME			(4*TICKS)

/*---------------------------------------------------------------------------
 * Utility Macros
 *---------------------------------------------------------------------------*/

/** @brief Returns the larger of two values */
#define max(a,b)	((a) > (b) ? (a) : (b))

/** @brief Returns the smaller of two values */
#define min(a,b)	((a) < (b) ? (a) : (b))

/** @brief Generate random number from 0 to (a-1) */
#define RANDOM(a)	(rand()%(a))

/*===========================================================================
 * ARRAY SIZE LIMITS
 * Maximum sizes for game object arrays - configured per area in main()
 *===========================================================================*/

/** @brief Map dimensions (256x256 tiles per area) */
#define MAXMAP		256

/** @brief Absolute maximum characters across all areas */
#define TOTAL_MAXCHARS	2048

/**
 * @brief Maximum items in this area (dynamic, set per area)
 * Typical values range from 20,480 to 49,152 depending on area needs
 */
#define MAXITEM		(maxitem)

/**
 * @brief Maximum characters in this area (dynamic, set per area)
 * Includes players and NPCs. Must be a multiple of 8.
 * Typical values: 256-2048 depending on area population
 */
#define MAXCHARS	(maxchars)

/**
 * @brief Maximum active effects in this area (dynamic)
 * Effects include spells, buffs, projectiles, etc.
 */
#define MAXEFFECT	(maxeffect)

/*---------------------------------------------------------------------------
 * String Length Limits
 *---------------------------------------------------------------------------*/

/** @brief Maximum length of area name strings */
#define MAXAREANAME	80

/** @brief Maximum password length for player accounts */
#define MAXPASSWORD	16

/** @brief Maximum email address length */
#define MAXEMAIL	80

/*---------------------------------------------------------------------------
 * Game Balance Constants
 *---------------------------------------------------------------------------*/

/**
 * @brief Scale factor for HP/Mana/Endurance calculations
 *
 * Character pools are calculated as: ch.hp = ch.value[0][V_HP] * POWERSCALE
 * This provides finer granularity for damage calculations and regeneration.
 * Example: A character with V_HP=100 has 100,000 actual HP points
 */
#define POWERSCALE	1000

/*---------------------------------------------------------------------------
 * Client Communication
 *---------------------------------------------------------------------------*/

#ifndef DIST
/**
 * @brief View distance for client updates (25 tiles in each direction)
 * Characters and items within this radius are sent to the client
 */
#define DIST		25
#endif

/*===========================================================================
 * SERVER STATUS VARIABLES (Global State)
 * These variables track the current state of the server instance
 *===========================================================================*/

/** @brief Dynamic array size limits, set based on areaID in main() */
extern int maxchars, maxitem, maxeffect;

/** @brief Quit flag - when set to 1, server begins graceful shutdown */
extern int quit;

/** @brief Daemon mode flag - 1 if running as background daemon */
extern int demon;

/** @brief Total memory usage tracking in bytes */
extern int mem_usage;

/**
 * @brief Global tick counter - increments every game tick (24/second)
 * Used for timing all game events, animations, and state updates
 */
extern int ticker;

/** @brief Serial number generator for characters (unique per server run) */
extern int sercn;

/** @brief Serial number generator for items (unique per server run) */
extern int serin;

/** @brief Current count of players online in this area */
extern int online;

/**
 * @brief Area ID this server instance is responsible for
 * Each game area (zone) runs as a separate server process
 * Valid values: 1-37 (see main() switch statement)
 */
extern int areaID;

/**
 * @brief Mirror number for this server instance
 * Allows multiple copies of same area for load balancing
 */
extern int areaM;

/** @brief Multi-threading flag - 1 if using separate thread for database */
extern int multi;

/** @brief IP address this server is bound to */
extern int server_addr;

/** @brief TCP port this server listens on */
extern int server_port;

/** @brief Current Unix timestamp, updated each tick */
extern int time_now;

/** @brief Server idle percentage (0-10000, where 10000 = 100% idle) */
extern int server_idle;

/** @brief Scheduled shutdown timestamp (0 = no shutdown scheduled) */
extern int shutdown_at;

/** @brief Countdown value for shutdown warning messages */
extern int shutdown_down;

/** @brief Login disabled flag - prevents new player connections */
extern int nologin;

/** @brief Server ID for client-side IP translation */
extern int serverID;

/** @brief Christmas event active flag */
extern int isxmas;

/*---------------------------------------------------------------------------
 * Network Statistics (thread-safe with volatile)
 *---------------------------------------------------------------------------*/

/** @brief Total bytes sent including TCP/IP overhead estimate */
extern volatile long long sent_bytes_raw;

/** @brief Actual payload bytes sent */
extern volatile long long sent_bytes;

/** @brief Total bytes received including TCP/IP overhead estimate */
extern volatile long long rec_bytes_raw;

/** @brief Actual payload bytes received */
extern volatile long long rec_bytes;


/*===========================================================================
 * MAP TILE DEFINITION
 *
 * The game world is a 256x256 grid of map tiles. Each tile contains:
 * - Background and foreground sprites for rendering
 * - Lighting information
 * - References to characters/items/effects on this tile
 * - Flags controlling movement, combat, and special behaviors
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Map Tile Flags (MF_*)
 * These flags define the properties and behaviors of each map tile
 *---------------------------------------------------------------------------*/

/** @brief Helper macro to cast flag bits to unsigned int */
#define MF_FLAGCAST(a)	((unsigned int)((a)))

/* Movement and Visibility Flags */
/** @brief Tile blocks all movement (walls, obstacles) */
#define MF_MOVEBLOCK    MF_FLAGCAST((1ULL<<0))

/** @brief Tile blocks line of sight (walls) */
#define MF_SIGHTBLOCK   MF_FLAGCAST((1ULL<<1))

/** @brief Temporary movement block (e.g., closed door) */
#define MF_TMOVEBLOCK   MF_FLAGCAST((1ULL<<2))

/** @brief Temporary sight block (e.g., closed door) */
#define MF_TSIGHTBLOCK  MF_FLAGCAST((1ULL<<3))

/* Environment Flags */
/** @brief Tile is indoors (affects daylight calculation) */
#define MF_INDOORS	MF_FLAGCAST((1ull<<4))

/** @brief Rest area - enhanced regeneration and safety */
#define MF_RESTAREA	MF_FLAGCAST((1ull<<5))

/** @brief Door tile - may open/close when used */
#define MF_DOOR		MF_FLAGCAST((1ull<<6))

/* Sound Propagation Flags */
/** @brief Blocks normal sound propagation */
#define MF_SOUNDBLOCK	MF_FLAGCAST((1ull<<7))

/** @brief Temporary sound block */
#define MF_TSOUNDBLOCK	MF_FLAGCAST((1ull<<8))

/** @brief Blocks ALL sounds including shouts */
#define MF_SHOUTBLOCK	MF_FLAGCAST((1ull<<9))

/* PvP Zone Flags */
/** @brief Clan territory - PvP allowed between warring clans */
#define MF_CLAN		MF_FLAGCAST((1ull<<10))

/** @brief Arena zone - unrestricted PvP allowed */
#define MF_ARENA	MF_FLAGCAST((1ull<<11))

/** @brief Peace zone - no combat allowed at all */
#define MF_PEACE	MF_FLAGCAST((1ull<<12))

/** @brief Neutral zone - NPCs won't attack peaceful characters */
#define MF_NEUTRAL	MF_FLAGCAST((1ull<<13))

/* Special Effect Flags */
/** @brief Fireballs can pass through this MOVEBLOCK tile */
#define MF_FIRETHRU	MF_FLAGCAST((1ull<<14))

/** @brief Hazard tile - players take damage over time (lava, poison, etc.) */
#define MF_SLOWDEATH	MF_FLAGCAST((1ull<<15))

/** @brief Darkness zone - no light from characters or items */
#define MF_NOLIGHT	MF_FLAGCAST((1ull<<16))

/** @brief Anti-magic zone - disables spells and stat bonuses */
#define MF_NOMAGIC	MF_FLAGCAST((1ull<<17))

/** @brief Underwater tile - requires oxygen or causes drowning */
#define MF_UNDERWATER	MF_FLAGCAST((1ull<<18))

/** @brief No regeneration on this tile */
#define MF_NOREGEN	MF_FLAGCAST((1ull<<19))

/**
 * @brief Map tile structure
 *
 * Each tile in the 256x256 game world grid uses this structure.
 * Tiles store display info, lighting, and references to objects on the tile.
 */
struct map
{
	/*--- Display ---*/
	/** @brief Background sprite ID (floor, ground, etc.) */
	unsigned int gsprite;

	/** @brief Foreground sprite ID (overlay objects) */
	unsigned int fsprite;

	/*--- Lighting ---*/
	/** @brief Daylight percentage (0-100, affected by time of day) */
	unsigned short dlight;

	/** @brief Local light strength from items/effects (not daylight) */
	short light;

	/*--- Object References ---*/
	/**
	 * @brief Character index on this tile (0 = none)
	 * Index into ch[] array - only one character per tile
	 */
	unsigned short ch;

	/**
	 * @brief Item index on this tile (0 = none)
	 * Index into it[] array - only one item per tile
	 */
	unsigned short it;

	/**
	 * @brief Effect indices on this tile
	 * Up to 4 simultaneous effects (spells, visuals) per tile
	 */
	unsigned short ef[4];

	/** @brief Tile flags (combination of MF_* flags) */
	unsigned int flags;
};

/**
 * @brief Global map array
 * Access as map[x + y * MAXMAP] or use the MAP() macro
 */
extern struct map *map;


/*===========================================================================
 * ITEM DEFINITION
 *
 * Items include everything that can exist in the game world:
 * - Equipment (weapons, armor, accessories)
 * - Consumables (potions, scrolls, food)
 * - Quest items and keys
 * - World objects (doors, chests, signs)
 * - Corpses and dropped loot
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Item Flags (IF_*)
 * These 64-bit flags define item properties and behaviors
 *---------------------------------------------------------------------------*/

/* Basic State Flags */
/** @brief Item slot is in use (not free) */
#define IF_USED		(1ull<<0)

/** @brief Item blocks movement when on ground (furniture, etc.) */
#define IF_MOVEBLOCK    (1ull<<1)

/** @brief Item blocks line of sight when on ground */
#define IF_SIGHTBLOCK   (1ull<<2)

/** @brief Item can be picked up */
#define IF_TAKE		(1ull<<3)

/** @brief Item can be used/activated */
#define IF_USE		(1ull<<4)

/*---------------------------------------------------------------------------
 * Equipment Slot Flags (IF_WN*)
 * Define which body slot(s) an item can be equipped to
 *---------------------------------------------------------------------------*/

/** @brief Can be worn on head (helmets, hats) */
#define IF_WNHEAD       (1ull<<5)

/** @brief Can be worn on neck (amulets, necklaces) */
#define IF_WNNECK       (1ull<<6)

/** @brief Can be worn on body (armor, robes) */
#define IF_WNBODY       (1ull<<7)

/** @brief Can be worn on arms (bracers, gloves) */
#define IF_WNARMS       (1ull<<8)

/** @brief Can be worn on belt (belts) */
#define IF_WNBELT       (1ull<<9)

/** @brief Can be worn on legs (leggings, pants) */
#define IF_WNLEGS       (1ull<<10)

/** @brief Can be worn on feet (boots, shoes) */
#define IF_WNFEET       (1ull<<11)

/** @brief Can be held in left hand (shields, off-hand) */
#define IF_WNLHAND      (1ull<<12)

/** @brief Can be held in right hand (weapons, main hand) */
#define IF_WNRHAND      (1ull<<13)

/** @brief Can be worn as cloak */
#define IF_WNCLOAK      (1ull<<14)

/** @brief Can be worn on left ring finger */
#define IF_WNLRING      (1ull<<15)

/** @brief Can be worn on right ring finger */
#define IF_WNRRING      (1ull<<16)

/** @brief Two-handed weapon - occupies both LHAND and RHAND */
#define IF_WNTWOHANDED	(1ull<<17)

/*---------------------------------------------------------------------------
 * Weapon Type Flags
 * Define the weapon category for skill requirements
 *---------------------------------------------------------------------------*/

/** @brief Weapon is an axe (uses Axe skill - not implemented) */
#define IF_AXE		(1ull<<18)

/** @brief Weapon is a dagger (uses Dagger skill) */
#define IF_DAGGER	(1ull<<19)

/** @brief Weapon is hand-to-hand (uses Hand-to-Hand skill) */
#define IF_HAND		(1ull<<20)

/** @brief Item is a shield (provides block chance) */
#define IF_SHIELD	(1ull<<21)

/** @brief Weapon is a staff (uses Staff skill) */
#define IF_STAFF	(1ull<<22)

/** @brief Weapon is a sword (uses Sword skill) */
#define IF_SWORD	(1ull<<23)

/** @brief Weapon is two-handed (uses Two-Handed skill) */
#define IF_TWOHAND	(1ull<<24)

/*---------------------------------------------------------------------------
 * Special Item Type Flags
 *---------------------------------------------------------------------------*/

/** @brief Item is a door - may open/close when used */
#define IF_DOOR		(1ull<<25)

/** @brief Quest item - cannot be dropped, traded, or destroyed */
#define IF_QUEST	(1ull<<26)

/** @brief Item blocks sound propagation */
#define IF_SOUNDBLOCK	(1ull<<27)

/** @brief Trigger item driver when character steps on this item */
#define IF_STEPACTION	(1ull<<28)

/** @brief Item is currency - auto-merges when picked up */
#define IF_MONEY	(1ull<<29)

/** @brief Item has custom decay logic (doesn't use standard decay timer) */
#define IF_NODECAY	(1ull<<30)

/** @brief Wall segment only visible from front (for isometric rendering) */
#define IF_FRONTWALL	(1ull<<31)

/*---------------------------------------------------------------------------
 * Storage and Binding Flags
 *---------------------------------------------------------------------------*/

/** @brief Item provides access to player depot (bank storage) */
#define IF_DEPOT	(1ull<<32)

/** @brief Item cannot be stored in depot or sold to vendors */
#define IF_NODEPOT	(1ull<<33)

/** @brief Item cannot be dropped on ground */
#define IF_NODROP	(1ull<<34)

/** @brief Item cannot be junked/destroyed by player */
#define IF_NOJUNK	(1ull<<35)

/** @brief Item is a player's corpse (contains their inventory) */
#define IF_PLAYERBODY	(1ull<<36)

/** @brief Soulbound item - only owner can pick up */
#define IF_BONDTAKE	(1ull<<37)

/** @brief Soulbound item - only owner can equip */
#define IF_BONDWEAR	(1ull<<38)

/** @brief Labyrinth item - not saved when changing areas */
#define IF_LABITEM	(1ull<<39)

/** @brief Item is in void storage (special driver-managed state) */
#define IF_VOID		(1ull<<40)

/** @brief Item cannot be enhanced with orbs/shrines/etc. */
#define IF_NOENHANCE	(1ull<<41)

/** @brief Item can exceed normal +20 modifier cap (3 mods) */
#define IF_BEYONDBOUNDS	(1ull<<42)

/** @brief Item modifiers bypass the max modifier check */
#define IF_BEYONDMAXMOD	(1ull<<43)

/*---------------------------------------------------------------------------
 * Composite Flag Macros
 *---------------------------------------------------------------------------*/

/** @brief Mask for all weapon type flags */
#define IF_WEAPON	(IF_AXE|IF_DAGGER|IF_HAND|IF_STAFF|IF_SWORD|IF_TWOHAND)

/** @brief Mask for all equipment slot flags */
#define IF_WEAR		(IF_WNHEAD|IF_WNNECK|IF_WNBODY|IF_WNARMS|IF_WNBELT|IF_WNLEGS|IF_WNFEET|IF_WNLHAND|IF_WNRHAND|IF_WNCLOAK|IF_WNLRING|IF_WNRRING)

/*---------------------------------------------------------------------------
 * Item Constants
 *---------------------------------------------------------------------------*/

/** @brief Maximum number of stat modifiers per item */
#define MAXMOD		5

/** @brief Size of item driver data block in bytes */
#define IT_DR_SIZE	40

/**
 * @brief Item structure - represents any object in the game world
 *
 * Items can be:
 * - On the ground (x, y set)
 * - Carried by a character (carried set)
 * - Inside a container (contained set)
 * - In the void (IF_VOID flag, managed by driver)
 *
 * Items can have up to MAXMOD (5) stat modifiers that affect the wielder.
 * Modifiers can be requirements (negative index) or bonuses (positive index).
 */
struct item
{
	/** @brief Item flags (combination of IF_* flags) */
	unsigned long long flags;

	/** @brief Display name (e.g., "Iron Sword", "Health Potion") */
	char name[40];

	/** @brief Detailed description shown on examine */
	char description[80];

	/*--- Game Data ---*/
	/** @brief Base value in gold pieces (for vendors/trading) */
	unsigned int value;

	/** @brief Minimum character level required to use this item */
	unsigned char min_level;

	/** @brief Maximum level (0 = no limit, used for scaling items) */
	unsigned char max_level;

	/**
	 * @brief Class restriction bitmask
	 * - 1 = Warrior only
	 * - 2 = Mage only
	 * - 4 = Seyan only (Warrior+Mage)
	 * - 8 = Arch class only
	 */
	unsigned char needs_class;

	/** @brief Expiration serial number for timed items */
	unsigned char expire_sn;

	/** @brief Owner's character ID for soulbound items */
	int ownerID;

	/*--- Stat Modifiers ---*/
	/**
	 * @brief Modifier indices into V_* stat constants
	 * - Positive values: stat bonuses when equipped
	 * - Negative values: stat requirements to use item
	 */
	signed short mod_index[MAXMOD];

	/** @brief Modifier values (amount of bonus or requirement) */
	signed short mod_value[MAXMOD];

	/*--- Location (mutually exclusive) ---*/
	/** @brief X coordinate on map (valid when > 0, item on ground) */
	unsigned short x;

	/** @brief Y coordinate on map (valid when > 0, item on ground) */
	unsigned short y;

	/** @brief Character index carrying this item (valid when > 0) */
	unsigned short carried;

	/** @brief Container index holding this item (valid when > 0) */
	unsigned short contained;

	/*--- Container ---*/
	/** @brief Container ID if this item can hold other items (chest, bag) */
	unsigned short content;

	/*--- Driver System ---*/
	/**
	 * @brief Item driver number
	 * Drivers handle special item behaviors (keys, quest items, etc.)
	 * 0 = no special driver
	 */
	unsigned short driver;

	/** @brief Driver-specific data storage (40 bytes) */
	unsigned char drdata[IT_DR_SIZE];

	/** @brief Persistent item ID (for database storage) */
	unsigned int ID;

	/** @brief Unique serial number for this server run */
	unsigned int serial;

	/*--- Display ---*/
	/** @brief Sprite ID for client rendering */
	int sprite;

	/*--- Memory Management ---*/
	/** @brief Next pointer for free list (internal use) */
	struct item *next;
};

/**
 * @brief Global item array
 * Items are accessed by index: it[in] where in = 1 to MAXITEM-1
 * Index 0 is reserved (invalid item)
 */
extern struct item *it;

/*===========================================================================
 * CHARACTER DEFINITION
 *
 * Characters represent all living entities in the game:
 * - Player characters (CF_PLAYER flag)
 * - NPCs (Non-Player Characters)
 * - Monsters and enemies
 * - Quest givers and merchants
 *
 * Each character has stats, equipment, position, and an optional driver
 * that controls their AI behavior.
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Character Flags (CF_*)
 * These 64-bit flags define character state and capabilities
 *---------------------------------------------------------------------------*/

/* Basic State Flags */
/** @brief Character slot is in use */
#define CF_USED		(1ull<<0)

/** @brief Character cannot take damage (god mode) */
#define CF_IMMORTAL     (1ull<<1)

/** @brief Character can use #god admin commands */
#define CF_GOD          (1ull<<2)

/** @brief Character is a player (not NPC) */
#define CF_PLAYER       (1ull<<3)

/** @brief Character is a staff member (GM/Admin) */
#define CF_STAFF        (1ull<<4)

/** @brief Character is completely invisible to others */
#define CF_INVISIBLE    (1ull<<5)

/** @brief Player is muted (cannot chat until next day) */
#define CF_SHUTUP       (1ull<<6)

/** @brief Player was kicked, cannot login for a period */
#define CF_KICKED       (1ull<<7)

/** @brief Client needs stat value update */
#define CF_UPDATE	(1ull<<8)

/** @brief Reserved - legacy flag, do not use */
#define CF_RESERVED0	(1ull<<9)

/** @brief Reserved - legacy flag, do not use */
#define CF_RESERVED1	(1ull<<10)

/** @brief Character is dying (death animation playing) */
#define CF_DEAD		(1ull<<11)

/** @brief Client needs inventory update */
#define CF_ITEMS	(1ull<<12)

/** @brief NPC will respawn after death */
#define CF_RESPAWN	(1ull<<13)

/* Gender Flags */
/** @brief Character is male */
#define CF_MALE	 	(1ull<<14)

/** @brief Character is female (neither = neuter) */
#define CF_FEMALE	(1ull<<15)

/*---------------------------------------------------------------------------
 * Class Flags
 * Classes determine available skills and stat growth
 *---------------------------------------------------------------------------*/

/**
 * @brief Warrior class flag
 * If both CF_WARRIOR and CF_MAGE are set, character is a Seyan'Du
 */
#define CF_WARRIOR	(1ull<<16)

/**
 * @brief Mage class flag
 * If both CF_WARRIOR and CF_MAGE are set, character is a Seyan'Du
 */
#define CF_MAGE		(1ull<<17)

/** @brief Arch class variant (enhanced version of base class) */
#define CF_ARCH		(1ull<<18)

/** @brief Reserved - legacy flag, do not use */
#define CF_RESERVED2	(1ull<<19)

/*---------------------------------------------------------------------------
 * Combat and Interaction Flags
 *---------------------------------------------------------------------------*/

/** @brief Character cannot be targeted by players */
#define CF_NOATTACK	(1ull<<20)

/** @brief NPC has unique name (e.g., "Shiva") vs generic ("Orc") */
#define CF_HASNAME	(1ull<<21)

/** @brief Character can receive quest items via 'give' command */
#define CF_QUESTITEM	(1ull<<22)

/** @brief NPC has infrared vision (sees invisible/stealthed) */
#define CF_INFRARED	(1ull<<23)

/** @brief Player has killed another player (PK flag) */
#define CF_PK		(1ull<<24)

/** @brief Character transforms into item on death (e.g., treasure chest) */
#define CF_ITEMDEATH	(1ull<<25)

/** @brief Character's death is handled by driver (special boss logic) */
#define CF_NODEATH	(1ull<<26)

/** @brief Character leaves no corpse */
#define CF_NOBODY	(1ull<<27)

/*---------------------------------------------------------------------------
 * Demon Type Flags (for special abilities)
 *---------------------------------------------------------------------------*/

/** @brief Earth demon - has earth-based abilities */
#define CF_EDEMON	(1ull<<28)

/** @brief Fire demon - has fire-based abilities */
#define CF_FDEMON	(1ull<<29)

/** @brief Ice demon - has ice-based abilities */
#define CF_IDEMON	(1ull<<30)

/*---------------------------------------------------------------------------
 * Additional Interaction Flags
 *---------------------------------------------------------------------------*/

/** @brief Character does not accept items via 'give' */
#define CF_NOGIVE	(1ull<<31)

/** @brief NPC treated as player for attack permission checks */
#define CF_PLAYERLIKE   (1ull<<32)

/** @brief Reserved - legacy flag, do not use */
#define CF_RESERVED3   	(1ull<<33)

/** @brief Player has active premium subscription */
#define CF_PAID   	(1ull<<34)

/** @brief Profession data needs update */
#define CF_PROF   	(1ull<<35)

/*---------------------------------------------------------------------------
 * Creature Type Flags (affects damage bonuses/vulnerabilities)
 *---------------------------------------------------------------------------*/

/** @brief Living creature (affected by infravision, life-based effects) */
#define CF_ALIVE	(1ull<<36)

/** @brief Demonic creature (extra damage from holy weapons) */
#define CF_DEMON	(1ull<<37)

/** @brief Undead creature (extra damage from holy weapons) */
#define CF_UNDEAD	(1ull<<38)

/** @brief Requires special weapon to kill (boss mechanic) */
#define CF_HARDKILL	(1ull<<39)

/** @brief Players cannot bless this character */
#define CF_NOBLESS	(1ull<<40)

/*---------------------------------------------------------------------------
 * State and Mode Flags
 *---------------------------------------------------------------------------*/

/** @brief Character is transferring between areas */
#define CF_AREACHANGE	(1ull<<41)

/** @brief Artificial lag enabled (anti-cheat/testing) */
#define CF_LAG		(1ull<<42)

/** @brief Reserved - legacy flag (was: completed main quest) */
#define CF_RESERVED4	(1ull<<43)

/** @brief Thief profession active mode (can steal) */
#define CF_THIEFMODE	(1ull<<44)

/** @brief Player has disabled private messages */
#define CF_NOTELL	(1ull<<45)

/** @brief Player has infrared vision (spell/item effect) */
#define CF_INFRAVISION	(1ull<<46)

/** @brief Character affected by anti-magic zone */
#define CF_NOMAGIC	(1ull<<47)

/** @brief Character immune to anti-magic zones */
#define CF_NONOMAGIC	(1ull<<48)

/** @brief Character can breathe underwater */
#define CF_OXYGEN	(1ull<<49)

/** @brief Character cannot attack/be attacked by players */
#define CF_NOPLRATT	(1ull<<50)

/** @brief NPC can be swapped positions with (normally NPCs can't) */
#define CF_ALLOWSWAP	(1ull<<51)

/** @brief Player can host Live Quests (GM events) */
#define CF_LQMASTER	(1ull<<52)

/** @brief Hardcore mode - permadeath, no saves, bonus XP */
#define CF_HARDCORE	(1ull<<53)

/** @brief Character doesn't broadcast position updates */
#define CF_NONOTIFY	(1ull<<54)

/** @brief Needs sector list update on next tick */
#define CF_SMALLUPDATE	(1ull<<55)

/** @brief Hidden from /who command */
#define CF_NOWHO	(1ull<<56)

/** @brief Player has completed the main quest (killed Islena) */
#define CF_WON		(1ull<<57)

/*===========================================================================
 * CHARACTER VALUES (V_*)
 *
 * These indices are used with ch.value[layer][V_xxx]:
 * - layer 0: Total calculated value (base + equipment + buffs)
 * - layer 1: Base value (natural stat, 0 = unknown/not trainable)
 *
 * Items and effects modify these values. Used for both attributes and skills.
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Resource Pools (Primary Stats)
 * These are multiplied by POWERSCALE for actual values
 *---------------------------------------------------------------------------*/

/** @brief Hit Points - determines survivability, calculated from WIS+STR */
#define V_HP		0

/** @brief Endurance - used for physical actions (running, attacking) */
#define V_ENDURANCE	1

/** @brief Mana - used for casting spells, calculated from WIS+INT */
#define V_MANA		2

/*---------------------------------------------------------------------------
 * Base Attributes
 * Core stats that affect derived values and skill effectiveness
 *---------------------------------------------------------------------------*/

/** @brief Wisdom - affects HP, Mana, and spell effectiveness */
#define V_WIS         	3

/** @brief Intelligence - affects Mana and spell damage */
#define V_INT          	4

/** @brief Agility - affects Speed, Parry, and physical skills */
#define V_AGI         	5

/** @brief Strength - affects HP, Weapon damage, and carrying capacity */
#define V_STR       	6

/*---------------------------------------------------------------------------
 * Combat Values (Derived)
 *---------------------------------------------------------------------------*/

/** @brief Armor value - damage reduction from equipped armor */
#define V_ARMOR		7

/** @brief Weapon value - base damage from equipped weapon */
#define V_WEAPON	8

/** @brief Light radius - how far character can see in dark */
#define V_LIGHT		9

/** @brief Movement speed - how fast character moves between tiles */
#define V_SPEED		10

/** @brief Attack speed modifier - affects time between attacks */
#define V_PULSE        	11

/*---------------------------------------------------------------------------
 * Weapon Skills
 * Each weapon type has its own skill that affects damage and accuracy
 *---------------------------------------------------------------------------*/

/** @brief Dagger skill - effectiveness with daggers */
#define V_DAGGER       	12

/** @brief Hand-to-Hand skill - effectiveness with fist weapons */
#define V_HAND         	13

/** @brief Staff skill - effectiveness with staves */
#define V_STAFF        	14

/** @brief Sword skill - effectiveness with swords */
#define V_SWORD        	15

/** @brief Two-Handed skill - effectiveness with two-handed weapons */
#define V_TWOHAND      	16

/*---------------------------------------------------------------------------
 * Combat Skills (Warrior)
 *---------------------------------------------------------------------------*/

/** @brief Armor skill - reduces armor penalties, increases effectiveness */
#define V_ARMORSKILL   	17

/** @brief Attack skill - increases hit chance and damage */
#define V_ATTACK       	18

/** @brief Parry skill - increases chance to block attacks */
#define V_PARRY	       	19

/** @brief Warcry skill - buffs allies and debuffs enemies */
#define V_WARCRY       	20

/** @brief Tactics skill - improves combat efficiency */
#define V_TACTICS      	21

/** @brief Surround Hit - ability to hit multiple enemies */
#define V_SURROUND     	22

/** @brief Body Control - reduces damage taken */
#define V_BODYCONTROL	23

/** @brief Speed skill - improves movement and attack speed */
#define V_SPEEDSKILL	24

/*---------------------------------------------------------------------------
 * Utility Skills
 *---------------------------------------------------------------------------*/

/** @brief Barter skill - better prices from merchants */
#define V_BARTER       	25

/** @brief Perception - detects hidden enemies and traps */
#define V_PERCEPT      	26

/** @brief Stealth - ability to hide from enemies */
#define V_STEALTH      	27

/*---------------------------------------------------------------------------
 * Magic Skills (Mage)
 *---------------------------------------------------------------------------*/

/** @brief Bless - buff spell that enhances ally stats */
#define V_BLESS		28

/** @brief Heal - restores HP to target */
#define V_HEAL		29

/** @brief Freeze - slows or immobilizes enemies */
#define V_FREEZE	30

/** @brief Magic Shield - absorbs incoming damage */
#define V_MAGICSHIELD	31

/** @brief Flash - blinds and damages enemies in radius */
#define V_FLASH		32

/** @brief Fireball - ranged fire damage spell */
#define V_FIREBALL	33

/** @brief Alias for V_FIREBALL */
#define V_FIRE		V_FIREBALL

/** @brief Empty slot (unused) */
#define V_EMPTY		34

/** @brief Regenerate - passive HP recovery skill */
#define V_REGENERATE	35

/** @brief Meditate - passive Mana recovery skill */
#define V_MEDITATE	36

/** @brief Immunity - resistance to magic effects */
#define V_IMMUNITY	37

/*---------------------------------------------------------------------------
 * Special Skills
 *---------------------------------------------------------------------------*/

/** @brief Demon skill - special demon-related abilities */
#define V_DEMON		38

/** @brief Duration - affects how long buffs/effects last */
#define V_DURATION	39

/** @brief Rage - berserk mode, increased damage at cost */
#define V_RAGE		40

/** @brief Cold resistance/damage */
#define V_COLD		41

/** @brief Profession points (used for profession system) */
#define V_PROFESSION	42

/** @brief Total number of V_* values */
#define V_MAX	       	43

/*===========================================================================
 * PROFESSIONS (P_*)
 *
 * Secondary skill trees that provide specialized abilities.
 * Characters can advance in multiple professions simultaneously.
 * Profession levels are stored in ch.prof[P_xxx]
 *===========================================================================*/

/** @brief Athlete - enhanced stamina and movement */
#define P_ATHLETE	0

/** @brief Alchemist - create potions and special items */
#define P_ALCHEMIST	1

/** @brief Miner - gather ore and craft materials */
#define P_MINER		2

/** @brief Assassin - enhanced stealth attacks */
#define P_ASSASSIN	3

/** @brief Thief - steal from NPCs and players */
#define P_THIEF		4

/** @brief Light - holy/healing abilities */
#define P_LIGHT		5

/** @brief Dark - shadow/curse abilities */
#define P_DARK		6

/** @brief Trader - better merchant prices */
#define P_TRADER	7

/** @brief Mercenary - enhanced combat bonuses */
#define P_MERCENARY	8

/** @brief Clan - clan-related bonuses */
#define P_CLAN		9

/** @brief Herbalist - gather and use herbs */
#define P_HERBALIST	10

/** @brief Demon - demonic powers */
#define P_DEMON		11

/** @brief Maximum number of professions */
#define P_MAX		20

/*===========================================================================
 * EQUIPMENT SLOTS (WN_*)
 *
 * Indices into ch.item[] array for equipped items (slots 0-11).
 * The remaining slots (12-INVENTORYSIZE) are general inventory.
 *===========================================================================*/

/** @brief Maximum length of character description string */
#define LENDESC		160

/** @brief Neck slot - amulets, necklaces */
#define WN_NECK         0

/** @brief Head slot - helmets, hats */
#define WN_HEAD         1

/** @brief Cloak slot - capes, cloaks */
#define WN_CLOAK        2

/** @brief Arms slot - bracers, gauntlets */
#define WN_ARMS         3

/** @brief Body slot - chest armor, robes */
#define WN_BODY         4

/** @brief Belt slot - belts */
#define WN_BELT         5

/** @brief Right hand - primary weapon */
#define WN_RHAND        6

/** @brief Legs slot - leggings, pants */
#define WN_LEGS         7

/** @brief Left hand - shield or off-hand weapon */
#define WN_LHAND        8

/** @brief Right ring finger */
#define WN_RRING        9

/** @brief Feet slot - boots, shoes */
#define WN_FEET         10

/** @brief Left ring finger */
#define WN_LRING        11

/*---------------------------------------------------------------------------
 * Movement Speed Modes
 *---------------------------------------------------------------------------*/

/** @brief Normal walking speed */
#define SM_NORMAL	0

/** @brief Running - faster but uses endurance */
#define SM_FAST		1

/** @brief Stealth mode - slower but harder to detect */
#define SM_STEALTH	2

/*---------------------------------------------------------------------------
 * Inventory Constants
 *---------------------------------------------------------------------------*/

/**
 * @brief Total inventory size
 * - Slots 0-11: Equipment (WN_* slots)
 * - Slots 12-29: Quick spell slots
 * - Slots 30-(INVENTORYSIZE-1): General inventory
 */
#define INVENTORYSIZE	110

/*===========================================================================
 * DRIVER DATA STRUCTURES
 *
 * The driver system allows attaching custom behavior and data to characters.
 * Each character can have multiple data blocks identified by unique IDs.
 * This is used for NPC AI, quest state, persistent player data, etc.
 *===========================================================================*/

/**
 * @brief Driver data block - linked list node for character data
 *
 * Used to attach arbitrary data structures to characters for drivers.
 * Each block has a unique ID (see DRD_* constants in drdata.h).
 */
struct data
{
	/** @brief Data block ID (DRD_* constant) */
	int ID;

	/** @brief Size of data in bytes */
	int size;

	/** @brief Pointer to actual data */
	void *data;

	/** @brief Linked list pointers */
	struct data *next, *prev;
};

/*===========================================================================
 * CHARACTER STRUCTURE
 *
 * The main structure representing any character in the game (player or NPC).
 * This is the most important data structure in the server.
 *
 * Characters are stored in the global ch[] array, accessed by index (cn).
 * Index 0 is reserved (invalid character).
 *===========================================================================*/

struct character
{
	/*=========================================================================
	 * IDENTITY
	 *=========================================================================*/

	/** @brief Character flags (combination of CF_* flags) */
	unsigned long long flags;

	/** @brief Character name (e.g., "Sir Galahad", "Skeleton Warrior") */
	char name[40];

	/** @brief Character description shown on examine */
	char description[LENDESC];

	/** @brief Persistent database ID (0 for NPCs without persistence) */
	unsigned int ID;

	/** @brief Index into player[] array (0 if not a player) */
	unsigned int player;

	/*=========================================================================
	 * DISPLAY
	 *=========================================================================*/

	/** @brief Base sprite ID for rendering */
	unsigned int sprite;

	/** @brief Sound ID for footsteps/voice */
	unsigned int sound;

	/*=========================================================================
	 * STATS AND ATTRIBUTES
	 *=========================================================================*/

	/**
	 * @brief Character stat values
	 * - value[0][V_xxx]: Total calculated value (base + items + buffs)
	 * - value[1][V_xxx]: Base/natural value (0 = cannot train this stat)
	 */
	short value[2][V_MAX];

	/*=========================================================================
	 * RESOURCE POOLS (Current Values)
	 * These are actual current values, multiplied by POWERSCALE
	 *=========================================================================*/

	/** @brief Current hit points (0 = dead) */
	int hp;

	/** @brief Current endurance (for running/fighting) */
	int endurance;

	/** @brief Current mana (for spells) */
	int mana;

	/** @brief Magic shield absorption remaining */
	int lifeshield;

	/** @brief Tick counter for regeneration timing */
	int regen_ticker;

	/*=========================================================================
	 * PROGRESSION
	 *=========================================================================*/

	/** @brief Total experience points earned */
	unsigned int exp;

	/** @brief Experience spent on raising stats/skills */
	unsigned int exp_used;

	/** @brief Character level (derived from exp) */
	unsigned int level;

	/*=========================================================================
	 * POSSESSIONS
	 *=========================================================================*/

	/** @brief Gold coins carried */
	unsigned int gold;

	/** @brief Item currently under mouse cursor (client state) */
	unsigned int citem;

	/**
	 * @brief Inventory array (item indices)
	 * - [0-11]: Equipment slots (see WN_* constants)
	 * - [12-29]: Quick spell/skill slots
	 * - [30-109]: General inventory
	 */
	unsigned int item[INVENTORYSIZE];

	/*=========================================================================
	 * COMMUNICATION
	 *=========================================================================*/

	/** @brief Chat channel subscription bitmap */
	unsigned int channel;

	/*=========================================================================
	 * POSITION AND MOVEMENT
	 *=========================================================================*/

	/** @brief Current X position on map */
	unsigned short x;

	/** @brief Current Y position on map */
	unsigned short y;

	/** @brief Target X position (moving to) */
	unsigned short tox;

	/** @brief Target Y position (moving to) */
	unsigned short toy;

	/** @brief Direction character is facing (0-7, 0=north) */
	unsigned char dir;

	/** @brief Previous character in sector list (for spatial queries) */
	unsigned int sec_prev;

	/** @brief Next character in sector list (for spatial queries) */
	unsigned int sec_next;

	/*=========================================================================
	 * ACTION STATE
	 *=========================================================================*/

	/** @brief Current action being performed (attack, cast, etc.) */
	unsigned short action;

	/** @brief Duration of current action in ticks */
	unsigned short duration;

	/** @brief Current step in action animation */
	unsigned short step;

	/** @brief Action parameter 1 (target cn, spell ID, etc.) */
	unsigned int act1;

	/** @brief Action parameter 2 (additional data) */
	unsigned int act2;

	/** @brief Movement mode (SM_NORMAL, SM_FAST, SM_STEALTH) */
	unsigned char speed_mode;

	/** @brief Merchant cn currently trading with (0 = none) */
	unsigned short merchant;

	/** @brief Container currently looking into (0 = none) */
	unsigned int con_in;

	/*=========================================================================
	 * DRIVER SYSTEM (AI/Behavior)
	 *=========================================================================*/

	/** @brief Driver number (determines AI behavior) */
	unsigned short driver;

	/** @brief Store ID if character operates a shop */
	unsigned short store;

	/** @brief Linked list of driver data blocks */
	struct data *dat;

	/** @brief Message queue head for driver communication */
	struct msg *msg;

	/** @brief Message queue tail */
	struct msg *msg_last;

	/** @brief Argument string from zone file definition */
	char *arg;

	/*=========================================================================
	 * NPC SPAWNING
	 *=========================================================================*/

	/** @brief NPC group ID (must be non-zero for NPCs) */
	unsigned int group;

	/** @brief Unique serial number for this server run */
	unsigned int serial;

	/** @brief Template number used to create this character */
	unsigned int tmp;

	/** @brief Respawn X position */
	unsigned int tmpx;

	/** @brief Respawn Y position */
	unsigned int tmpy;

	/** @brief Player: target area. NPC: per-run unique ID */
	unsigned int tmpa;

	/** @brief Tick when respawn should occur */
	unsigned int respawn;

	/** @brief NPC class for first-kill bonus system */
	unsigned int class;

	/*=========================================================================
	 * REST AREA (Respawn Point)
	 *=========================================================================*/

	/** @brief Rest area ID (where player respawns on death) */
	unsigned int resta;

	/** @brief Rest area X coordinate */
	unsigned int restx;

	/** @brief Rest area Y coordinate */
	unsigned int resty;

	/*=========================================================================
	 * MEMORY MANAGEMENT
	 *=========================================================================*/

	/** @brief Next pointer in free/used list */
	struct character *next;

	/** @brief Previous pointer in free/used list */
	struct character *prev;

	/*=========================================================================
	 * EFFECTS
	 *=========================================================================*/

	/** @brief Active effect indices on this character (up to 4) */
	int ef[4];

	/*=========================================================================
	 * PLAYER-ONLY DATA
	 *=========================================================================*/

	/** @brief Number of death saves accumulated */
	int saves;

	/*--- Clan ---*/
	/** @brief Clan membership ID (0 = not in a clan) */
	int clan;

	/** @brief Rank in clan (0=member, 4=leader) */
	int clan_rank;

	/** @brief Staff code for identifying staff members */
	char staff_code[4];

	/** @brief Clan serial to verify clan still exists */
	int clan_serial;

	/*--- Punishment ---*/
	/** @brief Karma points (negative = bad behavior) */
	int karma;

	/*--- Statistics ---*/
	/** @brief Real-world time spent logged in (seconds) */
	int login_time;

	/** @brief Total number of deaths */
	int deaths;

	/** @brief Number of times saved from death */
	int got_saved;

	/*--- Appearance ---*/
	/** @brief Color tint 1 (skin/primary) */
	unsigned short c1;

	/** @brief Color tint 2 (hair/secondary) */
	unsigned short c2;

	/** @brief Color tint 3 (clothes/tertiary) */
	unsigned short c3;

	/*--- Combat ---*/
	/** @brief Current rage level for rage skill */
	int rage;

	/** @brief Tick of last regeneration */
	int last_regen;

	/*--- Server Sync ---*/
	/** @brief Mirror number for cross-server tracking */
	int mirror;

	/*--- Payment ---*/
	/** @brief Premium subscription expiration timestamp */
	int paid_till;

	/*--- Professions ---*/
	/** @brief Profession levels (see P_* constants) */
	unsigned char prof[P_MAX];
};

/**
 * @brief Global character array
 * Characters are accessed by index: ch[cn] where cn = 1 to MAXCHARS-1
 * Index 0 is reserved (invalid character)
 */
extern struct character *ch;

/*===========================================================================
 * EFFECT DEFINITION
 *
 * Effects represent temporary magical or visual phenomena in the game:
 * - Buff/debuff auras on characters
 * - Projectiles (fireballs, arrows)
 * - Area effects (explosions, frost novas)
 * - Environmental effects (light sources, weather)
 *
 * Effects are stored in the global ef[] array and can affect multiple
 * map tiles simultaneously.
 *===========================================================================*/

/** @brief Maximum number of map tiles a single effect can influence */
#define MAXFIELD	256

/**
 * @brief Effect structure - represents spells, projectiles, and visual effects
 *
 * Effects have a lifetime (start to stop ticks) and can influence multiple
 * map tiles. They may be attached to a character (buffs) or exist independently
 * in the world (projectiles, area effects).
 */
struct effect
{
	/*--- Identity ---*/
	/** @brief Effect type (determines behavior and rendering) */
	int type;

	/** @brief Unique serial number for this server run */
	int serial;

	/** @brief Linked list pointers for effect management */
	struct effect *prev, *next;

	/*--- Timing ---*/
	/** @brief Tick when effect started */
	int start;

	/** @brief Tick when effect ends (0 = permanent until removed) */
	int stop;

	/*--- Source ---*/
	/** @brief Character index who created this effect (caster) */
	int cn;

	/** @brief Serial number of caster (for validation) */
	int sercn;

	/** @brief Effect strength (usually caster's skill level) */
	int strength;

	/** @brief Light radius emitted by this effect */
	int light;

	/*--- Area of Effect ---*/
	/** @brief Number of map tiles affected by this effect */
	int field_cnt;

	/** @brief Array of map indices (m = x + y*MAXMAP) affected */
	int m[MAXFIELD];

	/*--- Target ---*/
	/** @brief Character this effect is attached to (may differ from caster) */
	int efcn;

	/*--- Projectile Data (for missiles) ---*/
	/** @brief Starting X position */
	int frx;

	/** @brief Starting Y position */
	int fry;

	/** @brief Target X position */
	int tox;

	/** @brief Target Y position */
	int toy;

	/** @brief Current X position (for moving effects) */
	int x;

	/** @brief Current Y position (for moving effects) */
	int y;

	/** @brief Previous X position (for trail effects) */
	int lx;

	/** @brief Previous Y position (for trail effects) */
	int ly;

	/** @brief Number of enemies hit on last tick (for splash damage) */
	int number_of_enemies;

	/*--- Display ---*/
	/** @brief Base sprite ID for rendering (explosions, etc.) */
	int base_sprite;
} *ef;

/*===========================================================================
 * PROFILER API
 *
 * The server includes a built-in profiler for performance monitoring.
 * Use prof_start/prof_stop pairs around code sections to measure CPU time.
 * Results can be viewed with SIGTSTP (Ctrl+Z) or #prof command.
 *===========================================================================*/

/**
 * @brief Start profiling a task
 * @param task Task ID (0-99, see profname[] in server.c)
 * @return CPU cycle counter value to pass to prof_stop()
 */
unsigned long long prof_start(int task);

/**
 * @brief Stop profiling a task and record elapsed time
 * @param task Task ID (must match prof_start call)
 * @param cycle Value returned from prof_start()
 */
void prof_stop(int task, unsigned long long cycle);

/** @brief Display profiler results to log */
void show_prof(void);

/** @brief Initialize the profiler system */
int init_prof(void);

/** @brief Update profiler statistics (called each tick) */
void prof_update(void);

/**
 * @brief Show profiler results to a specific character
 * @param cn Character index to send results to
 */
void cmd_show_prof(int cn);

/*===========================================================================
 * MEMORY ALLOCATION SAFETY
 *
 * Standard C memory functions are disabled to force use of the custom
 * memory allocator (smalloc/xmalloc in mem.c). This helps track memory
 * usage and prevent leaks.
 *
 * For external programs that include this header, define EXTERNAL_PROGRAM
 * before including to allow normal malloc/free usage.
 *===========================================================================*/

#ifndef EXTERNAL_PROGRAM
#define malloc	error error error
#define calloc	error error error
#define realloc	error error error
#define free	error error error
#undef strdup
#define strdup	error error error
#endif
