/*

$Id: bank.h,v 1.1 2005/09/24 09:55:48 ssim Exp $

$Log: bank.h,v $
Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:11:49  sam
Added RCS tags


*/

struct bank_ppd
{
	int imperial_gold;
};

