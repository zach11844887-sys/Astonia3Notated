/*

$Id: btrace.h,v 1.1 2005/09/24 09:55:48 ssim Exp $

$Log: btrace.h,v $
Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:11:52  sam
Added RCS tags


*/

void btrace(char *msg);

