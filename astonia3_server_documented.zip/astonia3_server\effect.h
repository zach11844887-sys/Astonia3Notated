/**
 * @file effect.h
 * @brief Effect system for spells, projectiles, and visual effects
 *
 * This header defines the visual and gameplay effect system.
 * Effects are temporary phenomena that:
 * - Display visual feedback to players
 * - Deal damage over time or on impact
 * - Apply buffs/debuffs to characters
 * - Light up areas
 *
 * ## Effect Types (EF_*)
 *
 * Effects are categorized by their behavior:
 *
 * ### Projectiles
 * - EF_FIREBALL: Fire damage projectile
 * - EF_BALL: Lightning/energy ball
 * - EF_EDEMONBALL: Earth demon projectile
 *
 * ### Character Buffs/Effects
 * - EF_MAGICSHIELD: Damage absorption shield
 * - EF_BLESS: Stat buff aura
 * - EF_FREEZE: Slow/immobilize
 * - EF_HEAL: HP recovery effect
 * - EF_WARCRY: Combat buff aura
 * - EF_CURSE: Stat debuff
 *
 * ### Area Effects
 * - EF_FLASH: Blinding light burst
 * - EF_EXPLODE: Fireball explosion
 * - EF_EARTHRAIN: Falling rocks
 * - EF_EARTHMUD: Slowing mud
 * - EF_MIST: Obscuring fog
 *
 * ### Combat Visuals
 * - EF_STRIKE: Hit flash
 * - EF_PULSE: Attack pulse wave
 * - EF_BURN: Fire DoT visual
 *
 * ## Effect Structure
 *
 * Effects are stored in the global ef[] array and referenced by
 * map tiles (map.ef[]) and characters (ch.ef[]).
 *
 * @see server.h for struct effect definition
 * @see effect.c for implementation
 *
 * $Id: effect.h,v 1.1 2005/09/24 09:55:48 ssim Exp $
 */

/*===========================================================================
 * EFFECT TYPE CONSTANTS (EF_*)
 *===========================================================================*/

/** @brief No effect / invalid */
#define EF_NONE		0

/** @brief Fireball projectile spell */
#define EF_FIREBALL	1

/** @brief Magic Shield buff (damage absorption) */
#define EF_MAGICSHIELD	2

/** @brief Lightning/energy ball projectile */
#define EF_BALL		3

/** @brief Strike helper effect for ball/flash */
#define EF_STRIKE	4

/** @brief Flash spell (blinding light) */
#define EF_FLASH	5

/** @brief Fireball explosion on impact */
#define EF_EXPLODE	7

/** @brief Warcry buff aura */
#define EF_WARCRY	8

/** @brief Bless spell buff */
#define EF_BLESS	9

/** @brief Freeze spell slow/immobilize */
#define EF_FREEZE	10

/** @brief Heal spell effect */
#define EF_HEAL		11

/** @brief Burning damage over time */
#define EF_BURN		12

/** @brief Mist/fog effect */
#define EF_MIST		13

/** @brief Potion use effect */
#define EF_POTION	14

/** @brief Earth demon rain attack */
#define EF_EARTHRAIN	15

/** @brief Earth demon mud (slow) */
#define EF_EARTHMUD	16

/** @brief Earth demon ball projectile */
#define EF_EDEMONBALL	17

/** @brief Curse debuff */
#define EF_CURSE	18

/** @brief Capture effect */
#define EF_CAP		19

/** @brief Artificial lag effect */
#define EF_LAG		20

/** @brief Pulse attack wave */
#define EF_PULSE	21

/** @brief Pulse attack return */
#define EF_PULSEBACK	22

/** @brief Fire ring effect */
#define EF_FIRERING	23

/** @brief Underwater bubble */
#define EF_BUBBLE	24

extern int used_effects;

int init_effect(void);
void tick_effect(void);

void free_effect(int fn);
int remove_effect(int fn);

int create_fireball(int cn,int frx,int fry,int tox,int toy,int str);
int create_ball(int cn,int frx,int fry,int tox,int toy,int str);
int create_show_effect(int type,int cn,int start,int stop,int light,int strength);
int create_flash(int cn,int str,int duration);
int ishit_fireball(int cn,int frx,int fry,int tox,int toy,int (*isenemy)(int,int));
int calc_steps_ball(int cn,int frx,int fry,int tox,int toy);
int create_explosion(int maxage,int base);
int add_explosion(int fn,int x,int y);
void destroy_chareffects(int cn);
int create_earthrain(int cn,int x,int y,int strength);
int create_earthmud(int cn,int x,int y,int strength);
int create_mist(int x,int y);
int edemonball_map_block(int m);
int create_edemonball(int cn,int frx,int fry,int tox,int toy,int str,int base);
int remove_effect_char(int fn);
void create_pulse(int x,int y,int str);
int destroy_effect_type(int cn,int type);
int create_map_effect(int type,int x,int y,int start,int stop,int light,int strength);
