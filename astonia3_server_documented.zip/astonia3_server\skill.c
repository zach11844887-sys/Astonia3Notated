/**
 * @file skill.c
 * @brief Skill system definitions and experience calculations
 *
 * This file defines the complete skill system for Astonia 3:
 * - Skill definitions (names, base attributes, costs)
 * - Experience cost calculations for raising skills
 * - Skill caps based on class and mode
 *
 * ## Skill Types
 *
 * Each skill has a type that affects how it can be raised:
 * - **Type 0**: Derived value, cannot be directly raised (Armor, Weapon, Light, Speed)
 * - **Type 1**: Skill, can be raised with experience
 * - **Type 2**: Attribute (WIS, INT, AGI, STR), can be raised with experience
 * - **Type 3**: Power pool (HP, Endurance, Mana, Profession), can be raised with experience
 *
 * ## Base Attributes
 *
 * Skills have three base attribute indices that determine their effectiveness:
 * - base1, base2, base3: V_* constants or -1 if not applicable
 * - These affect the cap for that skill based on your attributes
 *
 * ## Class Differences
 *
 * - **Warriors**: Higher physical skill caps
 * - **Mages**: Higher magic skill caps
 * - **Seyan'Du** (both): Lower overall caps but access to all skills
 * - **Hardcore**: +7 to skill caps
 *
 * ## Supermax System
 *
 * Beyond the normal skill cap, players can "supermax" skills for extra cost.
 * This provides end-game progression for maxed characters.
 *
 * $Id: skill.c,v 1.1 2005/09/24 09:48:53 ssim Exp $
 */

#include "server.h"
#include "create.h"
#include "database.h"
#include "log.h"
#include "tool.h"
#include "skill.h"

/**
 * @brief Master skill definition table
 *
 * Each entry defines one skill/attribute with:
 * - name: Display name
 * - base1, base2, base3: Base attributes that affect cap (-1 = none)
 * - type: 0=derived, 1=skill, 2=attribute, 3=power
 * - cost: Base experience cost multiplier
 */
struct skill skill[V_MAX]={
	/*---------------------------------------------------------------------------
	 * POWER POOLS (Type 3)
	 * These resource pools determine combat capability
	 *---------------------------------------------------------------------------*/
	/*              Name              base1  base2  base3  type cost */
	{"Hitpoints",		   -1,   -1,   -1, 	3,	10},	/* V_HP (0) */
	{"Endurance",		   -1,   -1,   -1, 	3,	10},	/* V_ENDURANCE (1) */
	{"Mana",		   -1,   -1,   -1, 	3,	10},	/* V_MANA (2) */

	/*---------------------------------------------------------------------------
	 * ATTRIBUTES (Type 2)
	 * Core stats that affect all other skills
	 *---------------------------------------------------------------------------*/
	{"Wisdom",		   -1,   -1,   -1, 	2,	10},	/* V_WIS (3) */
	{"Intuition",		   -1,   -1,   -1, 	2,	10},	/* V_INT (4) - Intelligence */
	{"Agility",		   -1,   -1,   -1, 	2,	10},	/* V_AGI (5) */
	{"Strength",		   -1,   -1,   -1, 	2,	10},	/* V_STR (6) */

	/*---------------------------------------------------------------------------
	 * DERIVED VALUES (Type 0)
	 * Calculated from equipment/attributes, cannot be raised directly
	 *---------------------------------------------------------------------------*/
	{"Armor",		   -1,   -1,   -1, 	0,	 0},	/* V_ARMOR (7) */
	{"Weapon",		   -1,   -1,   -1, 	0,	 0},	/* V_WEAPON (8) */
	{"Light",		   -1,   -1,   -1, 	0,	 0},	/* V_LIGHT (9) */
	{"Speed",     		V_AGI,V_AGI,V_STR, 	0,	 0},	/* V_SPEED (10) */

	/*---------------------------------------------------------------------------
	 * COMBAT TIMING
	 *---------------------------------------------------------------------------*/
	{"Pulse",	  	V_INT,V_INT,V_WIS, 	1,	 1},	/* V_PULSE (11) - Attack speed */

	/*---------------------------------------------------------------------------
	 * PRIMARY WEAPON SKILLS (Type 1)
	 * Each weapon type has its own skill
	 *---------------------------------------------------------------------------*/
	{"Dagger",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_DAGGER (12) */
	{"Hand to Hand",	V_AGI,V_STR,V_STR, 	1,	 1},	/* V_HAND (13) */
	{"Staff",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_STAFF (14) */
	{"Sword",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_SWORD (15) */
	{"Two-Handed",		V_AGI,V_STR,V_STR, 	1,	 1},	/* V_TWOHAND (16) */

	/*---------------------------------------------------------------------------
	 * SECONDARY COMBAT SKILLS (Type 1)
	 * Enhance combat effectiveness
	 *---------------------------------------------------------------------------*/
	{"Armor Skill",		V_AGI,V_AGI,V_STR, 	1,	 1},	/* V_ARMORSKILL (17) */
	{"Attack",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_ATTACK (18) */
	{"Parry",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_PARRY (19) */
	{"Warcry",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_WARCRY (20) */
	{"Tactics",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_TACTICS (21) */
	{"Surround Hit",	V_INT,V_AGI,V_STR, 	1,	 1},	/* V_SURROUND (22) */
	{"Body Control",	V_INT,V_AGI,V_STR, 	1,	 1},	/* V_BODYCONTROL (23) */
	{"Speed Skill",		V_INT,V_AGI,V_STR, 	1,	 1},	/* V_SPEEDSKILL (24) */

	/*---------------------------------------------------------------------------
	 * UTILITY SKILLS (Type 1)
	 * Non-combat abilities
	 *---------------------------------------------------------------------------*/
	{"Bartering",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_BARTER (25) */
	{"Perception",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_PERCEPT (26) */
	{"Stealth",		V_INT,V_AGI,V_AGI, 	1,	 1},	/* V_STEALTH (27) */

	/*---------------------------------------------------------------------------
	 * MAGIC SPELLS (Type 1)
	 * Mage abilities
	 *---------------------------------------------------------------------------*/
	{"Bless",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_BLESS (28) */
	{"Heal",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_HEAL (29) */
	{"Freeze",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_FREEZE (30) */
	{"Magic Shield",	V_INT,V_INT,V_WIS, 	1,	 1},	/* V_MAGICSHIELD (31) */
	{"Lightning",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_FLASH (32) */
	{"Fire",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_FIREBALL (33) */
	{"empty",		V_INT,V_INT,V_WIS, 	1,	 1},	/* V_EMPTY (34) - unused */

	/*---------------------------------------------------------------------------
	 * PASSIVE SKILLS (Type 1)
	 * Always-active abilities
	 *---------------------------------------------------------------------------*/
	{"Regenerate",		V_STR,V_STR,V_STR, 	1,	 1},	/* V_REGENERATE (35) */
	{"Meditate",		V_WIS,V_WIS,V_WIS, 	1,	 1},	/* V_MEDITATE (36) */
	{"Immunity",		V_INT,V_WIS,V_STR, 	1,	 1},	/* V_IMMUNITY (37) */

	/*---------------------------------------------------------------------------
	 * SPECIAL SKILLS
	 *---------------------------------------------------------------------------*/
	{"Ancient Knowledge",	V_INT,V_WIS,V_STR, 	0,	 1},	/* V_DEMON (38) - Demon abilities */
	{"Duration",		V_INT,V_WIS,V_STR, 	1,	 1},	/* V_DURATION (39) - Buff length */
	{"Rage",		V_INT,V_STR,V_STR, 	1,	 1},	/* V_RAGE (40) - Berserk mode */
	{"Resist Cold",		   -1,   -1,   -1, 	0,	 1},	/* V_COLD (41) - Cold resistance */
	{"Profession",		   -1,   -1,   -1, 	3,	 1}	/* V_PROFESSION (42) - Prof points */
};

int raise_cost(int v,int n,int seyan)
{
	int nr;

	nr=n-skill[v].start+1+5;

	if (seyan) return max(1,nr*nr*nr*skill[v].cost*4/30);
        else return max(1,nr*nr*nr*skill[v].cost/10);
}

int supermax_canraise(int skl)
{
	switch(skl) {
		case V_WIS:
		case V_INT:
		case V_AGI:
		case V_STR:		return 2;

		case V_PULSE:
		case V_ARMORSKILL:
		case V_DAGGER:
		case V_HAND:
		case V_STAFF:
		case V_SWORD:
		case V_TWOHAND:
		case V_ATTACK:
		case V_PARRY:
		case V_WARCRY:
		case V_TACTICS:
		case V_SURROUND:
		case V_BODYCONTROL:
		case V_SPEEDSKILL:
		case V_BARTER:
		case V_PERCEPT:
		case V_STEALTH:
		case V_BLESS:
		case V_HEAL:
		case V_FREEZE:
		case V_MAGICSHIELD:
		case V_FLASH:
                case V_FIRE:
		case V_REGENERATE:
		case V_MEDITATE:
		case V_IMMUNITY:
		case V_DURATION:
		case V_RAGE:		return 1;

		default:		return 0;
	}
}

int supermax_cost(int cn,int skl,int val)
{
	int seyan;

	if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1; else seyan=0;

	return supermax_canraise(skl)*3000000+raise_cost(skl,val,seyan);
}

int skillmax(int cn)
{
	int seyan;

	if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1; else seyan=0;
	
	return (seyan ? 100 : 115) + ((ch[cn].flags&CF_HARDCORE) ? 7 : 0);
}

int calc_exp(int cn)
{
	int v,n,exp=0,seyan;

	if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1;
	else seyan=0;

	for (v=0; v<V_MAX; v++) {
		if (!ch[cn].value[1][v]) continue;
		if (!skill[v].cost) continue;
		
		for (n=skill[v].start+1; n<=ch[cn].value[1][v]; n++) {
			if ((ch[cn].flags&CF_PLAYER) && n-1>=skillmax(cn)) {
				exp+=supermax_cost(cn,v,n-1);
				//xlog("supermax %d: %d",n,supermax_cost(cn,v,n-1));
                        } else exp+=raise_cost(v,n-1,seyan);			
		}		
	}
       	
	return exp;
}

// raise value v of cn by 1, does error checking
int raise_value(int cn,int v)
{
	int cost,seyan;
	int hardcore=0;

        if (v<0 || v>V_MAX) return 0;

	if (!skill[v].cost) return 0;

	if (!ch[cn].value[1][v]) return 0;
	
	if (!(ch[cn].flags&CF_ARCH) && ch[cn].value[1][v]>49) return 0;

        if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1;
	else seyan=0;

	if (ch[cn].flags&CF_HARDCORE) hardcore=7;
	/*{
		if (seyan) hardcore=5;
		else hardcore=7;		
	}*/

	if (seyan && ch[cn].value[1][v]>99+hardcore) return 0;
	if (ch[cn].value[1][v]>114+hardcore) return 0;

	if (v==V_PROFESSION && ch[cn].value[1][v]>99) return 0;

        cost=raise_cost(v,ch[cn].value[1][v],seyan);
	if (ch[cn].exp_used+cost>ch[cn].exp) return 0;

	ch[cn].exp_used+=cost;

	ch[cn].value[1][v]++;
	
	update_char(cn);
	dlog(cn,0,"raised %s to %d",skill[v].name,ch[cn].value[1][v]);

	return 1;
}

// lower value v of cn by 1, does error checking
int lower_value(int cn,int v)
{
	int cost,seyan;

        if (v<0 || v>V_MAX) return 0;

	if (!skill[v].cost) return 0;

	if (ch[cn].value[1][v]<=skill[v].start) return 0;
	
        if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1;
	else seyan=0;

	ch[cn].value[1][v]--;

        cost=raise_cost(v,ch[cn].value[1][v],seyan);
        ch[cn].exp_used-=cost;
	
	update_char(cn);
	dlog(cn,0,"lowered %s to %d",skill[v].name,ch[cn].value[1][v]);

	return 1;
}

// raise value v of cn by 1 and give exp for it, does error checking
int raise_value_exp(int cn,int v)
{
	int cost,seyan;
	int hardcore=0;

        if (v<0 || v>V_MAX) return 0;

	if (!skill[v].cost) return 0;

	if (!ch[cn].value[1][v]) return 0;
	
	if (!(ch[cn].flags&CF_ARCH) && ch[cn].value[1][v]>49) return 0;

        if ((ch[cn].flags&(CF_WARRIOR|CF_MAGE))==(CF_WARRIOR|CF_MAGE)) seyan=1;
	else seyan=0;

	if (ch[cn].flags&CF_HARDCORE) hardcore=7;
	/*{
		if (seyan) hardcore=5;
		else hardcore=7;
	}*/

	if (seyan && ch[cn].value[1][v]>99+hardcore) return 0;
	if (ch[cn].value[1][v]>114+hardcore) return 0;

	if (v==V_PROFESSION && ch[cn].value[1][v]>99) return 0;

        cost=raise_cost(v,ch[cn].value[1][v],seyan);

	ch[cn].exp_used+=cost;
	ch[cn].exp+=cost;
	check_levelup(cn);

	ch[cn].value[1][v]++;
	
	update_char(cn);
	dlog(cn,0,"raised %s to %d",skill[v].name,ch[cn].value[1][v]);

	return 1;
}

