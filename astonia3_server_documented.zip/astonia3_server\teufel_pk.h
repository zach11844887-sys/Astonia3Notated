/*
 * $Id: teufel_pk.h,v 1.1 2006/04/26 16:05:44 ssim Exp $
 *
 * $Log: teufel_pk.h,v $
 * Revision 1.1  2006/04/26 16:05:44  ssim
 * Initial revision
 *
 */

int teufel_pk(int cn,int co);
void teufel_damage(int cn,int cc,int dam);
void teufel_death(int cn,int cc);


