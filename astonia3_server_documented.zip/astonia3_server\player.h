/**
 * @file player.h
 * @brief Player connection and session management for Astonia 3 Server
 *
 * This header defines structures and functions for managing connected players:
 * - Network connection handling (sockets, buffers)
 * - Client state caching (map, inventory, stats)
 * - Player action commands from client
 * - Session states (connecting, playing, exiting)
 *
 * ## Player vs Character
 *
 * - `struct player`: Network connection and client-side cache (player.h)
 * - `struct character`: Game entity data (server.h)
 *
 * A player struct is allocated when a client connects.
 * A character struct is allocated when they enter the game world.
 * `player.cn` links to `ch[cn].player` bidirectionally.
 *
 * ## Data Flow
 *
 * ```
 * Client -> inbuf -> parse command -> player.action/act1/act2
 *                                          |
 *                                    player_driver()
 *                                          |
 *                              character actions (do_xxx)
 *                                          |
 * Client <- obuf <- compress <- notify_char changes
 * ```
 *
 * $Id: player.h,v 1.3 2006/09/14 09:55:22 devel Exp $
 */

/*===========================================================================
 * PLAYER LIMITS AND CONSTANTS
 *===========================================================================*/

/** @brief Maximum concurrent player connections per area */
#define MAXPLAYER	256

/*---------------------------------------------------------------------------
 * Connection States (ST_*)
 *---------------------------------------------------------------------------*/

/** @brief Player is connecting/authenticating */
#define ST_CONNECT	1

/** @brief Player is in normal gameplay */
#define ST_NORMAL	2

/** @brief Player is exiting/disconnecting */
#define ST_EXIT		3

/*---------------------------------------------------------------------------
 * Player Action Commands (PAC_*)
 * These are actions requested by the client that the player_driver processes
 *---------------------------------------------------------------------------*/

/** @brief No action queued */
#define PAC_IDLE	0

/** @brief Move to position (act1=x, act2=y) */
#define PAC_MOVE	1

/** @brief Pick up item (act1=x, act2=y) */
#define PAC_TAKE	2

/** @brief Drop item (act1=x, act2=y) */
#define PAC_DROP	3

/** @brief Attack target (act1=target_cn, act2=serial) */
#define PAC_KILL	4

/** @brief Use item/object (act1=x, act2=y) */
#define PAC_USE		5

/** @brief Cast Bless spell (act1=target_cn) */
#define PAC_BLESS	6

/** @brief Cast Heal spell (act1=target_cn) */
#define PAC_HEAL	7

/** @brief Cast Freeze spell (act1=target_cn) */
#define PAC_FREEZE	8

/** @brief Cast Fireball spell (act1=target_cn, act2=serial) */
#define PAC_FIREBALL	9

/** @brief Cast Ball spell (act1=target_cn, act2=serial) */
#define PAC_BALL	10

/** @brief Cast Magic Shield on self */
#define PAC_MAGICSHIELD	11

/** @brief Cast Flash spell */
#define PAC_FLASH	12

/** @brief Use Warcry skill */
#define PAC_WARCRY	13

/** @brief Look at map position (examine) */
#define PAC_LOOK_MAP	14

/** @brief Give item to character */
#define PAC_GIVE	15

/** @brief Fireball variant 2 */
#define PAC_FIREBALL2	16

/** @brief Ball variant 2 */
#define PAC_BALL2	17

/** @brief Teleport action */
#define PAC_TELEPORT	18

/** @brief Pulse attack (fast attack) */
#define PAC_PULSE	19

/*---------------------------------------------------------------------------
 * Effect Limits
 *---------------------------------------------------------------------------*/

/** @brief Maximum effects tracked per player client */
#define MAXEF		64

/*===========================================================================
 * PLAYER STRUCTURE (Connection Management)
 * Only available when NEED_PLAYER_STRUCT is defined before including
 *===========================================================================*/

#ifdef NEED_PLAYER_STRUCT

/** @brief Output buffer size for network data (16KB) */
#define OBUFSIZE	16384

/** @brief Maximum scrollback buffer for complaint system */
#define MAXSCROLLBACK	8192

/**
 * @brief Queued command from client
 * Multiple commands can be queued for sequential execution
 */
struct cmd_queue
{
	int action;      /**< Action type (PAC_*) */
	int act1, act2;  /**< Action parameters */
};

/**
 * @brief Player connection structure
 *
 * Manages a single client connection including:
 * - Network socket and buffers
 * - Client-side state cache (to send only changes)
 * - Current action being performed
 * - Various client UI state
 */
struct player
{
	/*=========================================================================
	 * NETWORK CONNECTION
	 *=========================================================================*/

	/** @brief TCP socket file descriptor */
	int sock;

	/** @brief Client IP address */
	unsigned int addr;

	/** @brief Tick of last command received (for idle timeout) */
	int lastcmd;

	/*--- Input Buffer ---*/
	/** @brief Raw input buffer from client */
	unsigned char inbuf[256];

	/** @brief Current input buffer length */
	int in_len;

	/*--- Output Ring Buffer ---*/
	/** @brief Compressed output buffer to send */
	unsigned char obuf[OBUFSIZE];

	/** @brief Input pointer (write position) */
	int iptr;

	/** @brief Output pointer (read position) */
	int optr;

	/*--- Pre-compression Buffer ---*/
	/** @brief Data waiting to be compressed */
	unsigned char tbuf[OBUFSIZE];

	/** @brief Pre-compression buffer pointer */
	int tptr;

	/*=========================================================================
	 * CONNECTION STATE
	 *=========================================================================*/

	/** @brief Current state (ST_CONNECT, ST_NORMAL, ST_EXIT) */
	unsigned int state;

	/*=========================================================================
	 * CHARACTER LINK
	 *=========================================================================*/

	/** @brief Character's unique database ID */
	unsigned long long usnr;

	/** @brief Character index in ch[] array (0 = not in game) */
	unsigned int cn;

	/** @brief Password sent from client (for authentication) */
	char passwd[16];

	/** @brief Current text command from player (chat, slash commands) */
	char command[256];

	/*=========================================================================
	 * COMPRESSION
	 *=========================================================================*/

	/** @brief zlib compression stream state */
	struct z_stream_s zs;

	/*=========================================================================
	 * CLIENT STATE CACHE
	 * Server tracks what client knows to send only changes (delta updates)
	 *=========================================================================*/

	/** @brief Cached map tile data sent to client */
	struct cmap cmap[(DIST*2+1)*(DIST*2+1)];

	/** @brief Last known player position */
	int x, y;

	/** @brief Cached character stat values */
	short value[2][V_MAX];

	/** @brief Cached inventory item IDs */
	unsigned int item[INVENTORYSIZE];

	/** @brief Cached inventory item flags */
	unsigned int item_flags[INVENTORYSIZE];

	/** @brief Cached inventory item prices */
	unsigned int item_price[INVENTORYSIZE];

	/** @brief Cached HP/Mana/Endurance/Shield values */
	short hp, mana, endurance, lifeshield;

	/** @brief Current item (cursor) sprite ID */
	unsigned int citem_sprite;

	/** @brief Current item flags */
	unsigned int citem_flags;

	/** @brief Bitmap: client knows name of character X */
	unsigned char nameflag[TOTAL_MAXCHARS/8];

	/** @brief Cached experience values */
	unsigned int exp, exp_used, gold, mil_exp;

	/** @brief Cached movement mode */
	unsigned int speed_mode;

	/** @brief Cached combat mode */
	unsigned int fight_mode;

	/** @brief Cached rage value */
	int rage;

	/*=========================================================================
	 * CONTAINER/MERCHANT UI STATE
	 *=========================================================================*/

	/** @brief Container type (0=none, 1=corpse, 2=store) */
	int con_type;

	/** @brief Container/merchant name for UI */
	char con_name[80];

	/** @brief Number of items in open container */
	int con_cnt;

	/** @brief Item sprites in container */
	int container[INVENTORYSIZE];

	/** @brief Item prices (for stores) */
	int price[INVENTORYSIZE];

	/** @brief Current price display */
	int cprice;

	/*=========================================================================
	 * EFFECT CACHE
	 *=========================================================================*/

	/** @brief Cached effect data for client */
	union ceffect ceffect[MAXEF];

	/** @brief Effect serial numbers */
	unsigned int seffect[MAXEF];

	/** @brief Update flags */
	unsigned long long uf;

	/*=========================================================================
	 * PLAYER DRIVER STATE
	 *=========================================================================*/

	/** @brief Current action (PAC_*) */
	int action;

	/** @brief Action parameters */
	int act1, act2;

	/** @brief Command queue for sequential actions */
	struct cmd_queue queue[16];

	/** @brief Last tick received from client */
	int ticker;

	/** @brief Auto-fightback target cn */
	int next_fightback_cn;

	/** @brief Auto-fightback target serial */
	int next_fightback_serial;

	/** @brief Tick to perform fightback */
	int next_fightback_ticker;

	/** @brief Timer preventing fighting (peace period) */
	int nofight_timer;

	/** @brief Saved action buffer */
	unsigned char svactbuf[7];

	/*=========================================================================
	 * PERFORMANCE
	 *=========================================================================*/

	/** @brief Cached daylight value for optimization */
	int dlight;

	/*=========================================================================
	 * STATISTICS
	 *=========================================================================*/

	/** @brief Real-world login timestamp */
	int login_time;

	/*=========================================================================
	 * COMPLAINT/LOGGING
	 *=========================================================================*/

	/** @brief Scrollback buffer for complaint system */
	char scrollback[MAXSCROLLBACK];

	/** @brief Current position in scrollback */
	int scrollpos;
};

/**
 * @brief Global player connection array
 * Access as player[nr] where nr is the connection slot
 */
extern struct player **player;

#endif /* NEED_PLAYER_STRUCT */

/*===========================================================================
 * PLAYER API FUNCTIONS
 *===========================================================================*/

/*---------------------------------------------------------------------------
 * Core Player Management
 *---------------------------------------------------------------------------*/

/** @brief Process all connected players each tick */
void tick_player(void);

/**
 * @brief Send formatted message to player's log
 * @param nr Player connection slot
 * @param color Message color code
 * @param format Printf-style format string
 */
int log_player(int nr, int color, char *format, ...);

/**
 * @brief Mark whether client knows a character's name
 * Used to avoid resending name data unnecessarily
 */
void set_player_knows_name(int nr, int cn, int flag);

/**
 * @brief Kick a player connection
 * @param nr Player connection slot
 * @param reason Reason message to log
 */
void kick_player(int nr, char *reason);

/**
 * @brief Clean up and save a character exiting the game
 * @param cn Character index
 */
void exit_char(int cn);

/** @brief Save all connected players to database (periodic backup) */
void backup_players(void);

/**
 * @brief Transfer player to another area server
 * @param nr Player connection slot
 * @param server Target server IP
 * @param port Target server port
 */
void player_to_server(int nr, unsigned int server, int port);

/**
 * @brief Send inventory update to player
 * @param cn Our character
 * @param co Target character whose inventory to display
 */
void plr_send_inv(int cn, int co);

/*---------------------------------------------------------------------------
 * Player Driver
 *---------------------------------------------------------------------------*/

/**
 * @brief Main player character driver - processes player actions
 *
 * Called each tick for each connected player. Handles:
 * - Movement commands
 * - Combat actions
 * - Spell casting
 * - Item interactions
 *
 * @param cn Character index
 * @param ret Return value from last action
 * @param last_action Previous action code
 */
void player_driver(int cn, int ret, int last_action);

/** @brief Handle idle player (no commands received) */
void player_idle(int nr);

/**
 * @brief Handle client-initiated disconnect
 * @param nr Player connection slot
 * @param reason Reason for exit
 */
void player_client_exit(int nr, char *reason);

/** @brief Force kick a character from game */
void kick_char(int cn);

/*---------------------------------------------------------------------------
 * Logging and Support
 *---------------------------------------------------------------------------*/

/**
 * @brief Write to scrollback buffer for complaint system
 * Records chat/actions for staff review if complaints are filed
 */
void write_scrollback(int nr, int cn, char *reason, char *namea, char *nameb);

/** @brief List directory contents (staff command) */
void plr_ls(int cn, char *dir);

/** @brief Display file contents (staff command) */
void plr_cat(int cn, char *dir);

/*---------------------------------------------------------------------------
 * Client Communication
 *---------------------------------------------------------------------------*/

/**
 * @brief Send special packet to client
 * @param type Special packet type
 * @param opt1 Option parameter 1
 * @param opt2 Option parameter 2
 */
void player_special(int cn, unsigned int type, unsigned int opt1, unsigned int opt2);

/** @brief Reset cached name data for character */
void reset_name(int cn);

/** @brief Perform sanity checks on character data */
void sanity_check(int cn);

/** @brief Clear player's map cache (force resend) */
void player_reset_map_cache(int nr);

/** @brief Exit character with player-specific cleanup */
void exit_char_player(int cn);

/** @brief Get player's IP address */
unsigned int get_player_addr(int nr);

/**
 * @brief Send quest log data to client
 * @param cn Character index
 * @param nr Quest log entry number
 */
void sendquestlog(int cn, int nr);




