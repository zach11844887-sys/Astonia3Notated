#define MAXFLOWER	100

struct flower_ppd
{
	int ID[MAXFLOWER];
	int last_used[MAXFLOWER];
};

