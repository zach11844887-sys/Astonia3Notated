struct transport_ppd
{
	unsigned long long seen;
};

