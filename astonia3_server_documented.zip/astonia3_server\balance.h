/*

$Id: balance.h,v 1.1 2005/09/24 09:55:48 ssim Exp $

$Log: balance.h,v $
Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:11:48  sam
Added RCS tags


*/

#define ATTACK_DIV		5	// orig 5

#define FIREBALL_DAMAGE		5	// orig 5
#define STRIKE_DAMAGE		5	// orig 5

