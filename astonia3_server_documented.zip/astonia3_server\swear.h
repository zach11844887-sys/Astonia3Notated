/*

$Id: swear.h,v 1.2 2006/03/22 14:30:13 ssim Exp $

$Log: swear.h,v $
Revision 1.2  2006/03/22 14:30:13  ssim
added /shutup

Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:12:55  sam
Added RCS tags


*/

int swearing(int cn,char *ptr);
void swear_ban(int cn,int minutes);

