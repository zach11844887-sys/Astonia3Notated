/*

$Id: book.h,v 1.1 2005/09/24 09:55:48 ssim Exp $

$Log: book.h,v $
Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:11:51  sam
Added RCS tags


*/

#define BOOK_LOISAN1	0
#define BOOK_LOISAN2	1
#define BOOK_SUPERIOR1	2
#define BOOK_SUPERIOR2	3
#define BOOK_SUPERIOR3	4
#define BOOK_SUPERIOR4	5
#define BOOK_SUPERIOR5	6
#define BOOK_SUPERIOR6	7
#define BOOK_VAMPIRE1	8
#define BOOK_VAMPIRE2	9
#define BOOK_VAMPIRE3	10
#define BOOK_VAMPIRE4	11
#define BOOK_VAMPIRE5	12
#define BOOK_DEMON1	13
#define BOOK_DEMON2	14
#define BOOK_DEMON3	15
#define BOOK_DEMON4	16
#define BOOK_DEMON5	17
#define SIGN_EDEMON1	18
#define SIGN_EDEMON2	19
#define BOOK_EDEMON1	20
#define BOOK_EDEMON2	21
#define BOOK_EDEMON3	22
#define BOOK_EDEMON4	23
#define BOOK_IDEMON1	24
#define BOOK_IDEMON2	25
#define BOOK_IDEMON3	26
#define BOOK_SWAMP	27
#define BOOK_PALACE1	28
#define BOOK_PALACE2	29
#define BOOK_PALACE3	30
#define BOOK_RUNES1	31
#define BOOK_RUNES2	32
#define BOOK_RUNES3	33
#define BOOK_RUNES4	34
#define BOOK_RUNES5	35
#define BOOK_RUNES6	36
#define BOOK_RUNES7	37
#define BOOK_RUNES8	38
#define BOOK_BONES1	39
#define BOOK_BONES2	40
#define BOOK_EVILKIR	41
#define BOOK_SHRIKE	42

#define BOOK_LAB2_DIARY         100
#define BOOK_LAB2_DIARY_PAGE    101

