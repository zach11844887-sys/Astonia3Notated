/*

$Id: direction.h,v 1.1 2005/09/24 09:55:48 ssim Exp $

$Log: direction.h,v $
Revision 1.1  2005/09/24 09:55:48  ssim
Initial revision

Revision 1.2  2003/10/13 14:12:10  sam
Added RCS tags


*/

#define DX_RIGHT	1
#define DX_RIGHTDOWN	2
#define DX_DOWN		3
#define DX_LEFTDOWN	4
#define DX_LEFT		5
#define DX_LEFTUP	6
#define DX_UP		7
#define DX_RIGHTUP	8
