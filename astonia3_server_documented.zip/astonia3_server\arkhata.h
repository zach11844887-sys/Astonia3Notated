struct arkhata_ppd
{
	int rammy_state;
	int jaz_state;
	int fiona_state;
	int ramin_state;
	int monk_state;
	int monk_bits;
	int captain_state;
	int judge_state;
	int letter_bits;
	int jada_state;
	int pot_state;
	int hunter_state;
	int thai_state;
	int last_budda;
	int trainer_state;
	int kid_state;
	int clerk_state;
	int clerk_time;
	int clerk_bits;
	int krenach_state;
	int krenach_time;
};

